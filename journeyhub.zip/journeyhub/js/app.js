// ============================================================
// js/app.js  –  Shared helpers used across all pages
// ============================================================

// ── Session storage for current user ─────────────────────────
const Session = {
  get:   ()       => JSON.parse(sessionStorage.getItem('jh_user') || 'null'),
  set:   (user)   => sessionStorage.setItem('jh_user', JSON.stringify(user)),
  clear: ()       => sessionStorage.removeItem('jh_user'),
  isAdmin: ()     => ['admin'].includes(Session.get()?.role),
  isMgr:  ()     => ['admin','content_manager'].includes(Session.get()?.role),
};

// ── Toast notifications ───────────────────────────────────────
function toast(message, type = 'info') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = message;
  container.appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .3s';
    setTimeout(() => el.remove(), 300); }, 3000);
}

// ── Stars renderer ────────────────────────────────────────────
function starsHTML(rating, max = 5) {
  let html = '<span class="stars">';
  for (let i = 1; i <= max; i++) {
    html += `<span class="star${i > Math.round(rating) ? ' star-empty' : ''}">★</span>`;
  }
  return html + '</span>';
}

// ── Price label ───────────────────────────────────────────────
function priceLabel(range) {
  const map = { free: '<span class="price price-free">FREE</span>',
    budget: '<span class="price price-budget">$</span>',
    'mid-range': '<span class="price price-mid">$$</span>',
    luxury: '<span class="price price-luxury">$$$</span>' };
  return map[range] || '';
}

// ── Type icon ─────────────────────────────────────────────────
function typeIcon(type) {
  return { attraction: '🏛️', hotel: '🏨', restaurant: '🍽️' }[type] || '📍';
}

// ── Format date ───────────────────────────────────────────────
function fmt(dateStr) {
  if (!dateStr) return '—';
  return new Date(dateStr).toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' });
}

// ── Initials ─────────────────────────────────────────────────
function initials(name) {
  return (name || 'U').split(' ').slice(0,2).map(w => w[0]).join('').toUpperCase();
}

// ── Spinner ───────────────────────────────────────────────────
function spinner() { return '<div class="spinner"></div>'; }

// ── Navbar ────────────────────────────────────────────────────
function buildNavbar() {
  const nav = document.getElementById('navbar');
  if (!nav) return;
  const user = Session.get();
  const links = user
    ? `<a href="destinations.html">Explore</a>
       <a href="itineraries.html">My Trips</a>
       ${Session.isAdmin() ? '<a href="admin.html">Admin</a>' : ''}
       <div class="nav-dropdown">
         <div class="nav-avatar">${initials(user.full_name || user.username)}</div>
         <div class="nav-dropdown-menu">
           <a href="profile.html">My Profile</a>
           <a href="favorites.html">Favorites</a>
           <div class="sep"></div>
           <a href="#" id="nav-logout">Log out</a>
         </div>
       </div>`
    : `<a href="destinations.html">Explore</a>
       <a href="login.html" class="btn-nav">Sign In</a>`;
  nav.querySelector('.nav-links').innerHTML = links;

  document.getElementById('nav-logout')?.addEventListener('click', async (e) => {
    e.preventDefault();
    await Auth.logout();
    Session.clear();
    window.location.href = 'index.html';
  });

  // Highlight active link
  const current = location.pathname.split('/').pop();
  nav.querySelectorAll('.nav-links a').forEach(a => {
    if (a.getAttribute('href') === current) a.classList.add('active');
  });

  // Scroll shadow
  window.addEventListener('scroll', () =>
    nav.classList.toggle('scrolled', window.scrollY > 10));
}

// ── Redirect if not logged in ─────────────────────────────────
function requireAuth(redirect = 'login.html') {
  if (!Session.get()) { window.location.href = redirect; return false; }
  return true;
}

// ── Init on every page ────────────────────────────────────────
document.addEventListener('DOMContentLoaded', buildNavbar);
