// ============================================================
// js/home.js  –  Home page specific logic
// ============================================================

const CITY_IMAGES = {
  'Lahore':    'https://picsum.photos/seed/lahore/600/400',
  'Karachi':   'https://picsum.photos/seed/karachi/600/400',
  'Islamabad': 'https://picsum.photos/seed/islamabad/600/400',
  'Hunza':     'https://picsum.photos/seed/hunza/600/400',
  'Istanbul':  'https://picsum.photos/seed/istanbul/600/400',
  'Dubai':     'https://picsum.photos/seed/dubai/600/400',
  'London':    'https://picsum.photos/seed/london/600/400',
  'Tokyo':     'https://picsum.photos/seed/tokyo/600/400',
};

function cityImg(city) { 
  return CITY_IMAGES[city] || `https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=600&q=70`; 
}

function doSearch() {
  const btn = document.querySelector('.search-bar button');
  const q = document.getElementById('hero-search').value.trim();
  const b = document.getElementById('budget_pref').value;
  
  btn.classList.add('btn-loading');
  
  let url = 'destinations.html?';
  if (q) url += `keyword=${encodeURIComponent(q)}&`;
  if (b) url += `budget=${encodeURIComponent(b)}&`;
  
  setTimeout(() => {
    window.location.href = url.replace(/&$/, '');
  }, 400);
}

async function loadStats() {
  const res = await Admin.dashboard();
  if (!res.success) return;
  const c = res.data.counts;
  document.getElementById('stat-destinations').querySelector('strong').textContent = c.total_destinations;
  document.getElementById('stat-attractions').querySelector('strong').textContent = c.total_attractions;
  document.getElementById('stat-reviews').querySelector('strong').textContent = c.approved_reviews;
}

async function loadTopDestinations() {
  const el = document.getElementById('top-destinations');
  const res = await Destinations.top(6);
  if (!res.success || !res.data.length) { 
    el.innerHTML = '<p class="text-muted">No destinations found.</p>'; 
    return; 
  }
  el.innerHTML = res.data.map(d => `
    <a href="destination.html?id=${d.destination_id}" class="card" style="text-decoration:none;color:inherit">
      <div class="card-img-wrap">
        <img src="${cityImg(d.city)}" alt="${d.city}" loading="lazy" onerror="this.src='https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=600&q=70'" />
        <span class="card-badge">${d.country}</span>
      </div>
      <div class="card-body">
        <h3>${d.city}</h3>
        <p>${(d.avg_destination_rating ? starsHTML(d.avg_destination_rating) + ` <span style="font-size:12px;color:var(--ink-muted)">(${d.total_reviews} reviews)</span>` : 'No reviews yet')}</p>
        <div style="display:flex;gap:12px;font-size:12px;color:var(--ink-muted);margin-top:8px">
          <span>🏛️ ${d.sightseeing_count} sights</span>
          <span>🏨 ${d.hotel_count} hotels</span>
          <span>🍽️ ${d.restaurant_count} restaurants</span>
        </div>
      </div>
    </a>`).join('');
}

async function loadTopAttractions() {
  const el = document.getElementById('top-attractions');
  const res = await Attractions.aboveAvg();
  if (!res.success || !res.data.length) { 
    el.innerHTML = '<p class="text-muted">No data.</p>'; 
    return; 
  }
  el.innerHTML = res.data.slice(0,8).map(a => `
    <div class="card" style="cursor:default">
      <div class="card-body">
        <div style="font-size:28px;margin-bottom:10px">${typeIcon(a.type)}</div>
        <h4 style="margin-bottom:4px">${a.name}</h4>
        <p style="font-size:12px;margin-bottom:8px">${a.city}, ${a.country}</p>
        <div class="rating-row">
          ${starsHTML(a.rating_avg)}
          <span class="rating-num">${parseFloat(a.rating_avg).toFixed(1)}</span>
          <span class="rating-count">(${a.review_count})</span>
        </div>
      </div>
    </div>`).join('');
}

async function loadFeaturedTrips() {
  const el = document.getElementById('featured-trips');
  const res = await Itineraries.adminTrips(3);
  if (!res.success || !res.data.length) { 
    el.innerHTML = '<p class="text-muted">No featured trips available yet.</p>'; 
    return; 
  }
  
  el.innerHTML = res.data.map(i => `
    <div class="card">
      <div class="card-body">
        <h3 style="margin-bottom:8px">${i.title}</h3>
        <p style="font-size:14px;color:var(--ink-muted);margin-bottom:12px">
          ${i.notes ? i.notes.substring(0, 100) + '...' : 'A perfectly planned getaway.'}
        </p>
        <div style="display:flex; gap:12px; font-size:13px; font-weight:500; color:var(--ink)">
          <span>💰 $${i.total_budget || 0}</span>
          <span>📅 ${i.total_days} Days</span>
        </div>
      </div>
    </div>
  `).join('');
}

// ── PARALLAX EFFECT ───────────────────────────────────────────
function initParallax() {
  const hero = document.querySelector('.hero');
  window.addEventListener('scroll', () => {
    const scrolled = window.scrollY;
    hero.style.backgroundPositionY = (scrolled * 0.5) + 'px';
  });
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('hero-search')?.addEventListener('keydown', e => { if(e.key==='Enter') doSearch(); });
  loadStats();
  loadTopDestinations();
  loadFeaturedTrips();
  loadTopAttractions();
  initParallax();
});
