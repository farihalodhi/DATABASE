// ============================================================
// js/api.js  –  All API calls to the PHP backend
// ============================================================

const BASE = '/journeyhub/api';

// ── Core fetch wrapper ───────────────────────────────────────
async function apiFetch(path, options = {}) {
  try {
    const res = await fetch(BASE + path, {
      credentials: 'include',
      cache: 'no-store',
      headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
      ...options,
    });
    const data = await res.json();
    return { ok: res.ok, status: res.status, ...data };
  } catch (err) {
    return { ok: false, error: 'Network error. Is the server running?' };
  }
}

// ── Auth ─────────────────────────────────────────────────────
const Auth = {
  login:    (email, password) =>
    apiFetch('/users.php?action=login', { method: 'POST', body: JSON.stringify({ email, password }) }),
  register: (data) =>
    apiFetch('/users.php?action=register', { method: 'POST', body: JSON.stringify(data) }),
  logout:   () =>
    apiFetch('/users.php?action=logout', { method: 'POST' }),
  profile:  (userId = '') =>
    apiFetch(`/users.php?action=profile${userId ? '&user_id=' + userId : ''}`),
  updateProfile: (data) =>
    apiFetch('/users.php?action=update_profile', { method: 'POST', body: JSON.stringify(data) }),
  changePassword: (oldPassword, newPassword) =>
    apiFetch('/users.php?action=change_password', { method: 'POST',
      body: JSON.stringify({ old_password: oldPassword, new_password: newPassword }) }),
};

// ── Destinations ──────────────────────────────────────────────
const Destinations = {
  search:   (params = {}) => {
    const q = new URLSearchParams(params).toString();
    return apiFetch(`/destinations.php?action=search&${q}`);
  },
  get:      (id)   => apiFetch(`/destinations.php?action=get&id=${id}`),
  top:      (n=6)  => apiFetch(`/destinations.php?action=top&limit=${n}`),
  countries:()     => apiFetch('/destinations.php?action=countries'),
  attractions: (id, type = '') =>
    apiFetch(`/destinations.php?action=attractions&id=${id}${type ? '&type=' + type : ''}`),
  create:   (data) =>
    apiFetch('/destinations.php?action=create', { method: 'POST', body: JSON.stringify(data) }),
  update:   (id, data) =>
    apiFetch(`/destinations.php?action=update&id=${id}`, { method: 'POST', body: JSON.stringify(data) }),
  delete:   (id)   =>
    apiFetch(`/destinations.php?action=delete&id=${id}`, { method: 'POST', body: JSON.stringify({ destination_id: id }) }),
  ullTextSearch: (query) =>
    apiFetch(`/destinations.php?action=full_text_search&query=${encodeURIComponent(query)}`),
};

// ── Attractions ───────────────────────────────────────────────
const Attractions = {
  search:   (params) => {
    const q = new URLSearchParams(params).toString();
    return apiFetch(`/attractions.php?action=search&${q}`);
  },
  get:      (id)     => apiFetch(`/attractions.php?action=get&id=${id}`),
  topRated: (destId) => apiFetch(`/attractions.php?action=top_rated&dest_id=${destId}`),
  aboveAvg: ()       => apiFetch('/attractions.php?action=above_average'),
  budget:   (city)   => apiFetch(`/attractions.php?action=budget_friendly&city=${encodeURIComponent(city)}`),
  stats:    ()       => apiFetch('/attractions.php?action=dest_stats'),
  create:   (data)   =>
    apiFetch('/attractions.php?action=create', { method: 'POST', body: JSON.stringify(data) }),
  update:   (id, data) =>
    apiFetch(`/attractions.php?action=update&id=${id}`, { method: 'POST', body: JSON.stringify(data) }),
  delete:   (id)     =>
    apiFetch(`/attractions.php?action=delete&id=${id}`, { method: 'POST', body: JSON.stringify({ attraction_id: id }) }),
};

// ── Itineraries ───────────────────────────────────────────────
const Itineraries = {
  list:       ()       => apiFetch('/itineraries.php?action=list'),
  get:        (id)     => apiFetch(`/itineraries.php?action=get&id=${id}`),
  publicFeed: (n=20)   => apiFetch(`/itineraries.php?action=public&limit=${n}`),
  adminTrips: (n=6)    => apiFetch(`/itineraries.php?action=admin_trips&limit=${n}`),
  create:     (data)   =>
    apiFetch('/itineraries.php?action=create', { method: 'POST', body: JSON.stringify(data) }),
  update:     (id, data) =>
    apiFetch(`/itineraries.php?action=update&id=${id}`, { method: 'POST', body: JSON.stringify(data) }),
  addItem:    (data)   =>
    apiFetch('/itineraries.php?action=add_item', { method: 'POST', body: JSON.stringify(data) }),
  removeItem: (itemId) =>
    apiFetch(`/itineraries.php?action=remove_item&item_id=${itemId}`, { method: 'POST' }),
  delete:     (id)     =>
    apiFetch(`/itineraries.php?action=delete&id=${id}`, { method: 'POST', body: JSON.stringify({ itinerary_id: id }) }),
};

// ── Reviews ───────────────────────────────────────────────────
const Reviews = {
  post:           (data)    =>
    apiFetch('/reviews.php?action=post', { method: 'POST', body: JSON.stringify(data) }),
  forAttraction:  (id)      => apiFetch(`/reviews.php?action=for_attraction&id=${id}`),
  forDestination: (id)      => apiFetch(`/reviews.php?action=for_destination&id=${id}`),
  mine:           ()        => apiFetch('/reviews.php?action=mine'),
  pending:        ()        => apiFetch('/reviews.php?action=pending'),
  stats:          (id)      => apiFetch(`/reviews.php?action=stats&id=${id}`),
  delete:         (id)      =>
    apiFetch(`/reviews.php?action=delete&id=${id}`, { method: 'POST' }),
  moderate:       (id, status) =>
    apiFetch('/reviews.php?action=moderate', { method: 'POST', body: JSON.stringify({ review_id: id, status }) }),
};

// ── Favorites ─────────────────────────────────────────────────
const Favorites = {
  add:     (data) =>
    apiFetch('/favorites.php?action=add', { method: 'POST', body: JSON.stringify(data) }),
  remove:  (favId) =>
    apiFetch(`/favorites.php?action=remove&fav_id=${favId}`, { method: 'POST' }),
  list:    ()      => apiFetch('/favorites.php?action=list'),
  popular: (n=10)  => apiFetch(`/favorites.php?action=popular&limit=${n}`),
  check:   (destId, attrId) => {
    const q = destId ? `dest_id=${destId}` : `attr_id=${attrId}`;
    return apiFetch(`/favorites.php?action=check&${q}`);
  },
};

// ── Admin ─────────────────────────────────────────────────────
const Admin = {
  dashboard:     ()       => apiFetch('/admin.php?action=dashboard'),
  auditLog:      ()       => apiFetch('/admin.php?action=audit_log'),
  userReport:    ()       => apiFetch('/admin.php?action=user_report'),
  recommendations: (uid)  => apiFetch(`/admin.php?action=recommendations&user_id=${uid}`),
  updateEmergency: (data) =>
    apiFetch('/admin.php?action=update_emergency', { method: 'POST', body: JSON.stringify(data) }),
  allUsers:      (role='') => apiFetch(`/users.php?action=all${role ? '&role=' + role : ''}`),
  toggleStatus:  (userId, isActive) =>
    apiFetch('/users.php?action=toggle_status', { method: 'POST', body: JSON.stringify({ user_id: userId, is_active: isActive }) }),
  changeRole:    (userId, role) =>
    apiFetch('/users.php?action=change_role', { method: 'POST', body: JSON.stringify({ user_id: userId, role }) }),
  deleteUser:    (userId) =>
    apiFetch('/users.php?action=delete', { method: 'POST', body: JSON.stringify({ user_id: userId }) }),
};
