<?php session_start(); $_SESSION['user_id'] = 6; $_SESSION['role'] = 'traveler'; $_GET['action'] = 'list'; require 'api/favorites.php';
