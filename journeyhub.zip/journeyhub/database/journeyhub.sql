-- =============================================================
-- JourneyHub Travel Planning System - Full Database Schema
-- Course: Database Systems
-- =============================================================

DROP DATABASE IF EXISTS journeyhub;
CREATE DATABASE journeyhub CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE journeyhub;

-- =============================================================
-- TABLE 1: users
-- =============================================================
CREATE TABLE users (
    user_id     INT AUTO_INCREMENT PRIMARY KEY,
    username    VARCHAR(50)  UNIQUE NOT NULL,
    email       VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name   VARCHAR(100),
    role        ENUM('traveler','admin','content_manager','tourism_official') DEFAULT 'traveler',
    budget_pref ENUM('budget','mid-range','luxury') DEFAULT 'mid-range',
    interests   VARCHAR(500)  COMMENT 'comma-separated: beach,mountains,culture,food',
    is_active   BOOLEAN DEFAULT TRUE,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- =============================================================
-- TABLE 2: categories
-- =============================================================
CREATE TABLE categories (
    category_id  INT AUTO_INCREMENT PRIMARY KEY,
    name         VARCHAR(100) NOT NULL,
    description  TEXT,
    type         ENUM('attraction','hotel','restaurant','destination') NOT NULL
);

-- =============================================================
-- TABLE 3: destinations
-- =============================================================
CREATE TABLE destinations (
    destination_id    INT AUTO_INCREMENT PRIMARY KEY,
    country           VARCHAR(100) NOT NULL,
    city              VARCHAR(100) NOT NULL,
    description       TEXT,
    climate           VARCHAR(100),
    best_visit_season VARCHAR(100),
    emergency_contact VARCHAR(255),
    image_url         VARCHAR(500),
    is_active         BOOLEAN DEFAULT TRUE,
    created_by        INT,
    created_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(user_id) ON DELETE SET NULL,
    UNIQUE KEY uq_city_country (city, country)
);

-- =============================================================
-- TABLE 4: attractions  (covers hotels & restaurants too)
-- =============================================================
CREATE TABLE attractions (
    attraction_id INT AUTO_INCREMENT PRIMARY KEY,
    destination_id INT NOT NULL,
    category_id    INT,
    name           VARCHAR(200) NOT NULL,
    type           ENUM('attraction','hotel','restaurant') NOT NULL,
    description    TEXT,
    address        VARCHAR(500),
    price_range    ENUM('free','budget','mid-range','luxury'),
    rating_avg     DECIMAL(3,2) DEFAULT 0.00,
    review_count   INT DEFAULT 0,
    image_url      VARCHAR(500),
    opening_hours  VARCHAR(200),
    is_active      BOOLEAN DEFAULT TRUE,
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (destination_id) REFERENCES destinations(destination_id) ON DELETE CASCADE,
    FOREIGN KEY (category_id)    REFERENCES categories(category_id) ON DELETE SET NULL
);

-- =============================================================
-- TABLE 5: itineraries
-- =============================================================
CREATE TABLE itineraries (
    itinerary_id   INT AUTO_INCREMENT PRIMARY KEY,
    user_id        INT NOT NULL,
    destination_id INT,
    title          VARCHAR(200) NOT NULL,
    start_date     DATE,
    end_date       DATE,
    total_budget   DECIMAL(10,2),
    notes          TEXT,
    is_public      BOOLEAN DEFAULT FALSE,
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id)        REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (destination_id) REFERENCES destinations(destination_id) ON DELETE SET NULL
);

-- =============================================================
-- TABLE 6: itinerary_items
-- =============================================================
CREATE TABLE itinerary_items (
    item_id        INT AUTO_INCREMENT PRIMARY KEY,
    itinerary_id   INT NOT NULL,
    attraction_id  INT,
    day_number     INT  NOT NULL,
    visit_time     TIME,
    duration_mins  INT  COMMENT 'planned duration in minutes',
    notes          VARCHAR(500),
    order_in_day   INT DEFAULT 1,
    FOREIGN KEY (itinerary_id)  REFERENCES itineraries(itinerary_id) ON DELETE CASCADE,
    FOREIGN KEY (attraction_id) REFERENCES attractions(attraction_id) ON DELETE SET NULL
);

-- =============================================================
-- TABLE 7: reviews
-- =============================================================
CREATE TABLE reviews (
    review_id      INT AUTO_INCREMENT PRIMARY KEY,
    user_id        INT NOT NULL,
    attraction_id  INT  DEFAULT NULL,
    destination_id INT  DEFAULT NULL,
    rating         TINYINT NOT NULL,
    title          VARCHAR(200),
    content        TEXT,
    status         ENUM('pending','approved','rejected') DEFAULT 'pending',
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT chk_rating CHECK (rating BETWEEN 1 AND 5),
    CONSTRAINT chk_review_target CHECK (
        (attraction_id IS NOT NULL AND destination_id IS NULL) OR
        (attraction_id IS NULL AND destination_id IS NOT NULL)
    ),
    FOREIGN KEY (user_id)        REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (attraction_id)  REFERENCES attractions(attraction_id) ON DELETE CASCADE,
    FOREIGN KEY (destination_id) REFERENCES destinations(destination_id) ON DELETE CASCADE
);

-- =============================================================
-- TABLE 8: favorites
-- =============================================================
CREATE TABLE favorites (
    favorite_id    INT AUTO_INCREMENT PRIMARY KEY,
    user_id        INT NOT NULL,
    destination_id INT  DEFAULT NULL,
    attraction_id  INT  DEFAULT NULL,
    added_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id)        REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (destination_id) REFERENCES destinations(destination_id) ON DELETE CASCADE,
    FOREIGN KEY (attraction_id)  REFERENCES attractions(attraction_id) ON DELETE CASCADE,
    UNIQUE KEY uq_fav_dest (user_id, destination_id),
    UNIQUE KEY uq_fav_attr (user_id, attraction_id)
);

-- =============================================================
-- TABLE 9: audit_log  (tracks admin/system actions)
-- =============================================================
CREATE TABLE audit_log (
    log_id     INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT,
    action     VARCHAR(100) NOT NULL,
    table_name VARCHAR(100),
    record_id  INT,
    old_value  TEXT,
    new_value  TEXT,
    logged_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
);

-- =============================================================
-- VIEWS
-- =============================================================

-- View 1: Full destination info with attraction counts and avg ratings
CREATE VIEW vw_destination_summary AS
SELECT
    d.destination_id,
    d.country,
    d.city,
    d.description,
    d.climate,
    d.best_visit_season,
    d.emergency_contact,
    COUNT(DISTINCT a.attraction_id)                             AS total_attractions,
    COUNT(DISTINCT CASE WHEN a.type='hotel'       THEN a.attraction_id END) AS hotel_count,
    COUNT(DISTINCT CASE WHEN a.type='restaurant'  THEN a.attraction_id END) AS restaurant_count,
    COUNT(DISTINCT CASE WHEN a.type='attraction'  THEN a.attraction_id END) AS sightseeing_count,
    ROUND(AVG(r.rating), 2)                                     AS avg_destination_rating,
    COUNT(DISTINCT r.review_id)                                 AS total_reviews
FROM destinations d
LEFT JOIN attractions a  ON a.destination_id = d.destination_id AND a.is_active = TRUE
LEFT JOIN reviews    r  ON r.destination_id  = d.destination_id AND r.status     = 'approved'
WHERE d.is_active = TRUE
GROUP BY d.destination_id;

-- View 2: Attraction details with destination name and category
CREATE VIEW vw_attraction_details AS
SELECT
    a.attraction_id,
    a.name          AS attraction_name,
    a.type,
    a.description,
    a.address,
    a.price_range,
    a.rating_avg,
    a.review_count,
    a.opening_hours,
    d.city,
    d.country,
    c.name          AS category_name
FROM attractions a
JOIN  destinations d ON d.destination_id = a.destination_id
LEFT JOIN categories c  ON c.category_id     = a.category_id
WHERE a.is_active = TRUE;

-- View 3: User itinerary summary
CREATE VIEW vw_user_itineraries AS
SELECT
    i.itinerary_id,
    i.user_id,
    u.username,
    u.full_name,
    i.title,
    d.city          AS destination_city,
    d.country       AS destination_country,
    i.start_date,
    i.end_date,
    DATEDIFF(i.end_date, i.start_date) + 1 AS trip_days,
    i.total_budget,
    COUNT(ii.item_id)                       AS total_activities,
    i.is_public,
    i.created_at
FROM itineraries i
JOIN  users        u  ON u.user_id        = i.user_id
LEFT JOIN destinations d  ON d.destination_id = i.destination_id
LEFT JOIN itinerary_items ii ON ii.itinerary_id = i.itinerary_id
GROUP BY i.itinerary_id;

-- View 4: Approved reviews with user and target info
CREATE VIEW vw_approved_reviews AS
SELECT
    r.review_id,
    r.rating,
    r.title,
    r.content,
    r.created_at,
    u.username,
    u.full_name,
    COALESCE(a.name, d.city) AS reviewed_entity,
    CASE WHEN r.attraction_id IS NOT NULL THEN 'attraction' ELSE 'destination' END AS review_type
FROM reviews r
JOIN  users        u ON u.user_id       = r.user_id
LEFT JOIN attractions a ON a.attraction_id = r.attraction_id
LEFT JOIN destinations d ON d.destination_id = r.destination_id
WHERE r.status = 'approved';

-- View 5: Top-rated attractions per destination
CREATE VIEW vw_top_attractions AS
SELECT
    a.attraction_id,
    a.name,
    a.type,
    a.price_range,
    a.rating_avg,
    a.review_count,
    d.city,
    d.country,
    RANK() OVER (PARTITION BY d.destination_id ORDER BY a.rating_avg DESC, a.review_count DESC) AS rank_in_destination
FROM attractions a
JOIN destinations d ON d.destination_id = a.destination_id
WHERE a.is_active = TRUE AND a.review_count > 0;

-- =============================================================
-- STORED PROCEDURES
-- =============================================================

DELIMITER $$

-- Procedure 1: Register a new user
CREATE PROCEDURE sp_register_user(
    IN  p_username    VARCHAR(50),
    IN  p_email       VARCHAR(100),
    IN  p_password    VARCHAR(255),
    IN  p_full_name   VARCHAR(100),
    OUT p_user_id     INT,
    OUT p_message     VARCHAR(200)
)
BEGIN
    DECLARE v_exists INT DEFAULT 0;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SET p_user_id = -1;
        SET p_message = 'Database error during registration.';
    END;

    START TRANSACTION;
        SELECT COUNT(*) INTO v_exists FROM users WHERE email = p_email OR username = p_username;
        IF v_exists > 0 THEN
            SET p_user_id = 0;
            SET p_message = 'Username or email already exists.';
            ROLLBACK;
        ELSE
            INSERT INTO users (username, email, password_hash, full_name)
            VALUES (p_username, p_email, p_password, p_full_name);
            SET p_user_id = LAST_INSERT_ID();
            SET p_message = 'User registered successfully.';
            COMMIT;
        END IF;
END$$

-- Procedure 2: Create itinerary with initial item in one transaction
CREATE PROCEDURE sp_create_itinerary(
    IN  p_user_id        INT,
    IN  p_destination_id INT,
    IN  p_title          VARCHAR(200),
    IN  p_start_date     DATE,
    IN  p_end_date       DATE,
    IN  p_budget         DECIMAL(10,2),
    OUT p_itinerary_id   INT,
    OUT p_message        VARCHAR(200)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SET p_itinerary_id = -1;
        SET p_message = 'Failed to create itinerary.';
    END;

    START TRANSACTION;
        INSERT INTO itineraries (user_id, destination_id, title, start_date, end_date, total_budget)
        VALUES (p_user_id, p_destination_id, p_title, p_start_date, p_end_date, p_budget);
        SET p_itinerary_id = LAST_INSERT_ID();

        -- Log the creation
        INSERT INTO audit_log (user_id, action, table_name, record_id, new_value)
        VALUES (p_user_id, 'CREATE_ITINERARY', 'itineraries', p_itinerary_id, p_title);
        SET p_message = 'Itinerary created successfully.';
    COMMIT;
END$$

-- Procedure 3: Approve / Reject a review and update attraction rating
CREATE PROCEDURE sp_moderate_review(
    IN p_admin_id    INT,
    IN p_review_id   INT,
    IN p_new_status  ENUM('approved','rejected')
)
BEGIN
    DECLARE v_attraction_id INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
    END;

    START TRANSACTION;
        SELECT attraction_id INTO v_attraction_id FROM reviews WHERE review_id = p_review_id;

        UPDATE reviews SET status = p_new_status WHERE review_id = p_review_id;

        -- Recalculate attraction rating if applicable
        IF v_attraction_id IS NOT NULL THEN
            UPDATE attractions
            SET rating_avg   = (SELECT ROUND(AVG(rating),2) FROM reviews WHERE attraction_id = v_attraction_id AND status = 'approved'),
                review_count = (SELECT COUNT(*)             FROM reviews WHERE attraction_id = v_attraction_id AND status = 'approved')
            WHERE attraction_id = v_attraction_id;
        END IF;

        INSERT INTO audit_log (user_id, action, table_name, record_id, new_value)
        VALUES (p_admin_id, CONCAT('REVIEW_', p_new_status), 'reviews', p_review_id, p_new_status);
    COMMIT;
END$$

-- Procedure 4: Search destinations (used by traveler)
CREATE PROCEDURE sp_search_destinations(
    IN p_keyword VARCHAR(100),
    IN p_country VARCHAR(100),
    IN p_season  VARCHAR(50)
)
BEGIN
    SELECT
        d.destination_id,
        d.country,
        d.city,
        d.description,
        d.climate,
        d.best_visit_season,
        COUNT(DISTINCT a.attraction_id) AS attraction_count,
        ROUND(AVG(r.rating),2)          AS avg_rating
    FROM destinations d
    LEFT JOIN attractions a ON a.destination_id = d.destination_id AND a.is_active = TRUE
    LEFT JOIN reviews     r ON r.destination_id = d.destination_id AND r.status = 'approved'
    WHERE d.is_active = TRUE
      AND (p_keyword IS NULL OR d.city    LIKE CONCAT('%', p_keyword, '%')
                             OR d.country LIKE CONCAT('%', p_keyword, '%')
                             OR d.description LIKE CONCAT('%', p_keyword, '%'))
      AND (p_country IS NULL OR d.country = p_country)
      AND (p_season  IS NULL OR d.best_visit_season LIKE CONCAT('%', p_season, '%'))
    GROUP BY d.destination_id
    ORDER BY avg_rating DESC;
END$$

-- Procedure 5: Get personalised recommendations based on user budget pref
CREATE PROCEDURE sp_get_recommendations(IN p_user_id INT)
BEGIN
    DECLARE v_budget  VARCHAR(20);
    DECLARE v_interests VARCHAR(500);

    SELECT budget_pref, interests INTO v_budget, v_interests
    FROM users WHERE user_id = p_user_id;

    SELECT
        a.attraction_id,
        a.name,
        a.type,
        a.description,
        a.price_range,
        a.rating_avg,
        a.review_count,
        d.city,
        d.country
    FROM attractions a
    JOIN destinations d ON d.destination_id = a.destination_id
    WHERE a.is_active = TRUE
      AND (v_budget IS NULL OR a.price_range = v_budget OR a.price_range = 'free')
      AND a.attraction_id NOT IN (
            SELECT DISTINCT f.attraction_id FROM favorites f WHERE f.user_id = p_user_id AND f.attraction_id IS NOT NULL
          )
    ORDER BY a.rating_avg DESC, a.review_count DESC
    LIMIT 20;
END$$

DELIMITER ;

-- =============================================================
-- FUNCTIONS
-- =============================================================

DELIMITER $$

-- Function 1: Calculate trip duration in days
CREATE FUNCTION fn_trip_duration(p_start DATE, p_end DATE)
RETURNS INT
DETERMINISTIC
BEGIN
    RETURN DATEDIFF(p_end, p_start) + 1;
END$$

-- Function 2: Get user's total itineraries count
CREATE FUNCTION fn_user_itinerary_count(p_user_id INT)
RETURNS INT
READS SQL DATA
BEGIN
    DECLARE v_count INT;
    SELECT COUNT(*) INTO v_count FROM itineraries WHERE user_id = p_user_id;
    RETURN v_count;
END$$

-- Function 3: Convert price range to symbol
CREATE FUNCTION fn_price_symbol(p_price_range VARCHAR(20))
RETURNS VARCHAR(10)
DETERMINISTIC
BEGIN
    RETURN CASE p_price_range
        WHEN 'free'      THEN 'FREE'
        WHEN 'budget'    THEN '$'
        WHEN 'mid-range' THEN '$$'
        WHEN 'luxury'    THEN '$$$'
        ELSE '?'
    END;
END$$

DELIMITER ;

-- =============================================================
-- TRIGGERS
-- =============================================================

DELIMITER $$

-- Trigger 1: After inserting an approved review, update attraction rating
CREATE TRIGGER trg_after_review_insert
AFTER INSERT ON reviews
FOR EACH ROW
BEGIN
    IF NEW.status = 'approved' AND NEW.attraction_id IS NOT NULL THEN
        UPDATE attractions
        SET rating_avg   = (SELECT ROUND(AVG(rating),2) FROM reviews WHERE attraction_id = NEW.attraction_id AND status = 'approved'),
            review_count = (SELECT COUNT(*)             FROM reviews WHERE attraction_id = NEW.attraction_id AND status = 'approved')
        WHERE attraction_id = NEW.attraction_id;
    END IF;
END$$

-- Trigger 2: After updating a review status, refresh attraction rating
CREATE TRIGGER trg_after_review_update
AFTER UPDATE ON reviews
FOR EACH ROW
BEGIN
    IF NEW.attraction_id IS NOT NULL AND (NEW.status != OLD.status) THEN
        UPDATE attractions
        SET rating_avg   = (SELECT ROUND(AVG(rating),2) FROM reviews WHERE attraction_id = NEW.attraction_id AND status = 'approved'),
            review_count = (SELECT COUNT(*)             FROM reviews WHERE attraction_id = NEW.attraction_id AND status = 'approved')
        WHERE attraction_id = NEW.attraction_id;
    END IF;
END$$

-- Trigger 3: Log whenever a user is deactivated
CREATE TRIGGER trg_user_deactivated
AFTER UPDATE ON users
FOR EACH ROW
BEGIN
    IF OLD.is_active = TRUE AND NEW.is_active = FALSE THEN
        INSERT INTO audit_log (user_id, action, table_name, record_id, old_value, new_value)
        VALUES (NEW.user_id, 'USER_DEACTIVATED', 'users', NEW.user_id, 'active', 'inactive');
    END IF;
END$$

DELIMITER ;

-- =============================================================
-- SAMPLE DATA
-- =============================================================

-- Admin + Sample Users (passwords are SHA2 hashed: 'password123')
INSERT INTO users (username, email, password_hash, full_name, role, budget_pref, interests) VALUES
('admin',        'admin@journeyhub.com',   SHA2('admin2024',256),    'System Admin',       'admin',            'luxury',    'culture,history'),
('content_mgr',  'content@journeyhub.com', SHA2('content2024',256),  'Sara Content',       'content_manager',  'mid-range', 'food,culture'),
('ali_traveler', 'ali@email.com',          SHA2('password123',256),  'Ali Hassan',         'traveler',         'budget',    'beach,food'),
('sara_travel',  'sara@email.com',         SHA2('password123',256),  'Sara Ahmed',         'traveler',         'mid-range', 'mountains,culture'),
('tourism_off',  'tourism@gov.pk',         SHA2('tourism2024',256),  'Tourism Official PK','tourism_official', 'mid-range', 'culture,history');

-- Categories
INSERT INTO categories (name, description, type) VALUES
('Historical Sites',   'Ancient monuments and heritage', 'attraction'),
('Beach & Nature',     'Beaches, parks, and natural wonders', 'attraction'),
('Adventure Sports',   'Hiking, rafting, and outdoor thrills', 'attraction'),
('Luxury Hotels',      'Five star accommodation', 'hotel'),
('Budget Hotels',      'Affordable stays', 'hotel'),
('Fine Dining',        'Upscale restaurants', 'restaurant'),
('Street Food',        'Local street food spots', 'restaurant'),
('City Destinations',  'Major urban centres', 'destination');

-- Destinations
INSERT INTO destinations (country, city, description, climate, best_visit_season, emergency_contact, created_by) VALUES
('Pakistan',  'Lahore',    'The cultural capital of Pakistan rich in Mughal history.', 'Semi-arid',   'October–March', '1122',       1),
('Pakistan',  'Karachi',   'Pakistan''s largest city and financial hub on the Arabian Sea.', 'Tropical', 'November–February', '115', 1),
('Pakistan',  'Islamabad', 'The modern capital city nestled near the Margalla Hills.', 'Humid subtropical', 'March–May', '1122', 1),
('Pakistan',  'Hunza',     'Stunning mountain valley in Gilgit-Baltistan.', 'Alpine', 'April–October', '1122', 1),
('Turkey',    'Istanbul',  'Historic city bridging Europe and Asia on the Bosphorus.', 'Mediterranean', 'April–October', '155', 1),
('UAE',       'Dubai',     'Futuristic city known for luxury and record-breaking architecture.', 'Desert', 'November–March', '999', 1),
('UK',        'London',    'Historic and modern capital on the River Thames.', 'Temperate', 'May–September', '999', 1),
('Japan',     'Tokyo',     'Bustling metropolis blending neon-lit skyscrapers with historic temples.', 'Humid subtropical', 'March–May, Sep–Nov', '110', 1);

-- Attractions
INSERT INTO attractions (destination_id, category_id, name, type, description, address, price_range, opening_hours) VALUES
-- Lahore
(1,1,'Badshahi Mosque',     'attraction','17th-century Mughal mosque, one of the world''s largest.','The Mall, Lahore','free','06:00-22:00'),
(1,1,'Lahore Fort',         'attraction','UNESCO World Heritage Mughal fort complex.','Fort Rd, Lahore','budget','09:00-17:00'),
(1,4,'Pearl Continental Lahore','hotel','Five-star luxury hotel in central Lahore.','Shahrah-e-Quaid-e-Azam','luxury',NULL),
(1,7,'Gawalmandi Food Street','restaurant','Famous street food hub with traditional cuisine.','Gawalmandi, Lahore','budget','18:00-02:00'),
-- Karachi
(2,2,'Clifton Beach',       'attraction','Popular sandy beach on the Arabian Sea.','Clifton, Karachi','free','Open 24h'),
(2,1,'Quaid-e-Azam Mausoleum','attraction','Marble mausoleum of Pakistan''s founding father.','M.A. Jinnah Rd, Karachi','free','06:00-22:00'),
(2,4,'Movenpick Hotel',     'hotel','Luxury hotel overlooking the Arabian Sea.','Club Rd, Karachi','luxury',NULL),
(2,6,'BBQ Tonight',         'restaurant','Award-winning Pakistani BBQ restaurant.','Clifton, Karachi','mid-range','18:00-01:00'),
-- Islamabad
(3,2,'Daman-e-Koh',         'attraction','Hilltop viewpoint with panoramic city views.','Margalla Hills, Islamabad','free','07:00-22:00'),
(3,4,'Serena Hotel Islamabad','hotel','Elegant five-star hotel in the diplomatic enclave.','Khayaban-e-Suhrawardy','luxury',NULL),
-- Hunza
(4,3,'Rakaposhi Base Camp', 'attraction','Trek to the base of 7,788m Rakaposhi peak.','Hunza Valley','free','Daylight hours'),
(4,5,'Eagle''s Nest Hotel', 'hotel','Iconic guesthouse with breathtaking valley views.','Duikar, Hunza','budget',NULL),
-- Istanbul
(5,1,'Hagia Sophia',        'attraction','6th-century Byzantine cathedral, now a mosque.','Sultanahmet, Istanbul','budget','09:00-17:00'),
(5,1,'Topkapi Palace',      'attraction','Ottoman palace museum with imperial treasures.','Sultanahmet, Istanbul','mid-range','09:00-17:00'),
(5,6,'Nusr-Et Steakhouse',  'restaurant','World-famous steakhouse by Salt Bae.','Etiler, Istanbul','luxury','12:00-00:00'),
-- Dubai
(6,1,'Burj Khalifa',        'attraction','World''s tallest building with observation decks.','Downtown Dubai','mid-range','10:00-22:00'),
(6,2,'Dubai Mall',          'attraction','Mega shopping and entertainment complex.','Financial Centre Rd, Dubai','free','10:00-00:00'),
(6,4,'Atlantis The Palm',   'hotel','Iconic luxury resort on Palm Jumeirah.','Palm Jumeirah, Dubai','luxury',NULL),
-- London
(7,1,'Tower of London',     'attraction','Historic castle and fortress on the Thames.','London EC3N 4AB','mid-range','09:00-17:30'),
(7,2,'Hyde Park',           'attraction','Major park in Central London.','London','free','05:00-00:00'),
(7,4,'The Ritz London',     'hotel','Iconic 5-star hotel in Piccadilly.','150 Piccadilly, London','luxury',NULL),
(7,6,'Gordon Ramsay Grill', 'restaurant','Signature dishes by the famous chef.','Grosvenor Square, London','luxury','12:00-23:00'),
-- Tokyo
(8,1,'Senso-ji Temple',     'attraction','Tokyo''s oldest Buddhist temple in Asakusa.','Asakusa, Tokyo','free','06:00-17:00'),
(8,2,'Shibuya Crossing',    'attraction','World''s busiest pedestrian crossing.','Shibuya, Tokyo','free','Open 24h'),
(8,4,'Park Hyatt Tokyo',    'hotel','Luxury hotel offering sweeping city views.','Shinjuku, Tokyo','luxury',NULL),
(8,7,'Tsukiji Market',      'restaurant','Bustling market with fresh sushi.','Chuo City, Tokyo','mid-range','05:00-14:00');

-- Sample Reviews (submitted by travelers)
INSERT INTO reviews (user_id, attraction_id, rating, title, content, status) VALUES
(3,1,5,'Breathtaking!','Badshahi Mosque is one of the most beautiful structures I have ever seen.','approved'),
(4,1,4,'A must-visit','Incredible architecture but gets crowded on weekends.','approved'),
(3,5,5,'Lovely beach','Great place to relax with family. Clean and well maintained.','approved'),
(4,13,5,'Hagia Sophia is magical','The history inside this building is overwhelming. Must visit.','approved'),
(3,16,4,'Amazing views','Burj Khalifa observation deck is worth every penny.','approved'),
(4,2,4,'Great fort','Rich history, well-preserved. Guides are informative.','pending');

-- Update attraction ratings from approved reviews
UPDATE attractions a
JOIN (SELECT attraction_id, ROUND(AVG(rating),2) AS avg_r, COUNT(*) AS cnt
      FROM reviews WHERE status='approved' GROUP BY attraction_id) r
  ON a.attraction_id = r.attraction_id
SET a.rating_avg = r.avg_r, a.review_count = r.cnt;

-- Sample Itineraries
INSERT INTO itineraries (user_id, destination_id, title, start_date, end_date, total_budget, is_public) VALUES
(3, 1, 'Lahore Cultural Weekend', '2025-12-20', '2025-12-22', 15000.00, TRUE),
(4, 5, 'Istanbul History Tour',   '2026-03-10', '2026-03-17', 1200.00,  TRUE);

-- Itinerary Items
INSERT INTO itinerary_items (itinerary_id, attraction_id, day_number, visit_time, duration_mins, notes, order_in_day) VALUES
(1, 1, 1, '09:00:00', 120, 'Morning visit to Badshahi Mosque', 1),
(1, 2, 1, '12:00:00', 150, 'Afternoon at Lahore Fort', 2),
(1, 4, 1, '20:00:00', 90,  'Evening street food at Gawalmandi', 3),
(2,13, 1, '10:00:00', 180, 'Hagia Sophia – book tickets in advance', 1),
(2,14, 1, '14:00:00', 120, 'Topkapi Palace afternoon', 2);

-- Sample Favorites
INSERT INTO favorites (user_id, destination_id) VALUES (3,1),(3,5),(4,5),(4,6);
INSERT INTO favorites (user_id, attraction_id)  VALUES (3,1),(3,5),(4,13),(4,16);

-- =============================================================
-- ADVANCED QUERIES (for reference / testing)
-- =============================================================

-- Q1: INNER JOIN – Attractions with their destination and category
-- SELECT a.name, a.type, a.price_range, d.city, d.country, c.name AS category
-- FROM attractions a
-- JOIN destinations d ON d.destination_id = a.destination_id
-- LEFT JOIN categories c ON c.category_id = a.category_id
-- WHERE a.is_active = TRUE ORDER BY d.city, a.type;

-- Q2: GROUP BY + HAVING – Destinations with more than 3 attractions
-- SELECT d.city, d.country, COUNT(a.attraction_id) AS total
-- FROM destinations d
-- JOIN attractions a ON a.destination_id = d.destination_id
-- GROUP BY d.destination_id HAVING total > 3;

-- Q3: Subquery – Attractions with above-average rating
-- SELECT name, type, rating_avg FROM attractions
-- WHERE rating_avg > (SELECT AVG(rating_avg) FROM attractions WHERE rating_avg > 0)
-- ORDER BY rating_avg DESC;

-- Q4: Window Function – Rank attractions per destination
-- SELECT name, city, rating_avg,
--   RANK() OVER (PARTITION BY destination_id ORDER BY rating_avg DESC) AS dest_rank
-- FROM vw_attraction_details;

-- Q5: Built-in functions – Date, string, numeric
-- SELECT u.username, u.full_name, UPPER(u.role) AS role,
--   DATE_FORMAT(u.created_at,'%d %M %Y') AS joined,
--   DATEDIFF(NOW(), u.created_at) AS days_since_joined,
--   fn_user_itinerary_count(u.user_id) AS itineraries
-- FROM users u WHERE u.is_active = TRUE;

-- Q6: Transaction – Add itinerary item and log
-- START TRANSACTION;
-- INSERT INTO itinerary_items (itinerary_id, attraction_id, day_number, visit_time, duration_mins)
--   VALUES (1, 3, 2, '14:00:00', 60);
-- INSERT INTO audit_log (user_id, action, table_name, record_id)
--   VALUES (3, 'ADD_ITEM', 'itinerary_items', LAST_INSERT_ID());
-- COMMIT;
