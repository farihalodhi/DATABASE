-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 10, 2026 at 01:18 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `journeyhub`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_create_itinerary` (IN `p_user_id` INT, IN `p_destination_id` INT, IN `p_title` VARCHAR(200), IN `p_start_date` DATE, IN `p_end_date` DATE, IN `p_budget` DECIMAL(10,2), OUT `p_itinerary_id` INT, OUT `p_message` VARCHAR(200))   BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SET p_itinerary_id = -1;
        SET p_message = 'Failed to create itinerary.';
    END;

    START TRANSACTION;
        INSERT INTO itineraries (user_id, destination_id, title, start_date, end_date, total_budget)
        VALUES (p_user_id, p_destination_id, p_title, p_start_date, p_end_date, p_budget);
        SET p_itinerary_id = LAST_INSERT_ID();

        -- Log the creation
        INSERT INTO audit_log (user_id, action, table_name, record_id, new_value)
        VALUES (p_user_id, 'CREATE_ITINERARY', 'itineraries', p_itinerary_id, p_title);
        SET p_message = 'Itinerary created successfully.';
    COMMIT;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_destination_report` (IN `p_country` VARCHAR(100))   BEGIN
    SELECT
        d.city,
        d.country,
        d.climate,
        d.best_visit_season,
        COUNT(DISTINCT a.attraction_id)                                     AS total_attractions,
        COUNT(DISTINCT CASE WHEN a.type='hotel'      THEN a.attraction_id END) AS hotels,
        COUNT(DISTINCT CASE WHEN a.type='restaurant' THEN a.attraction_id END) AS restaurants,
        COUNT(DISTINCT CASE WHEN a.type='attraction' THEN a.attraction_id END) AS sights,
        ROUND(AVG(CASE WHEN r.status='approved' THEN r.rating END), 2)      AS avg_rating,
        COUNT(DISTINCT CASE WHEN r.status='approved' THEN r.review_id END)  AS approved_reviews,
        COUNT(DISTINCT i.itinerary_id)                                      AS times_planned,
        COUNT(DISTINCT f.favorite_id)                                       AS times_favorited
    FROM destinations d
    LEFT JOIN attractions   a ON a.destination_id = d.destination_id AND a.is_active = TRUE
    LEFT JOIN reviews       r ON r.destination_id = d.destination_id
    LEFT JOIN itineraries   i ON i.destination_id = d.destination_id
    LEFT JOIN favorites     f ON f.destination_id = d.destination_id
    WHERE d.country = p_country AND d.is_active = TRUE
    GROUP BY d.destination_id
    ORDER BY avg_rating DESC;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_full_text_search` (IN `p_query` VARCHAR(200))   BEGIN
    -- Search destinations
    SELECT
        'destination'               AS result_type,
        d.destination_id            AS entity_id,
        d.city                      AS title,
        d.country                   AS subtitle,
        d.description               AS excerpt,
        MATCH(d.city, d.country, d.description)
            AGAINST(p_query IN NATURAL LANGUAGE MODE) AS relevance
    FROM destinations d
    WHERE d.is_active = TRUE
      AND MATCH(d.city, d.country, d.description)
          AGAINST(p_query IN NATURAL LANGUAGE MODE)

    UNION ALL

    -- Search attractions
    SELECT
        'attraction'                AS result_type,
        a.attraction_id             AS entity_id,
        a.name                      AS title,
        CONCAT(d.city, ', ', d.country) AS subtitle,
        a.description               AS excerpt,
        MATCH(a.name, a.description, a.address)
            AGAINST(p_query IN NATURAL LANGUAGE MODE) AS relevance
    FROM attractions a
    JOIN destinations d ON d.destination_id = a.destination_id
    WHERE a.is_active = TRUE
      AND MATCH(a.name, a.description, a.address)
          AGAINST(p_query IN NATURAL LANGUAGE MODE)

    ORDER BY relevance DESC
    LIMIT 20;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_get_recommendations` (IN `p_user_id` INT)   BEGIN
    DECLARE v_budget    VARCHAR(20);
    DECLARE v_interests VARCHAR(500);

    SELECT budget_pref, interests
    INTO   v_budget, v_interests
    FROM   users WHERE user_id = p_user_id;

    SELECT
        a.attraction_id,
        a.name,
        a.type,
        a.description,
        a.price_range,
        fn_price_symbol(a.price_range) AS price_symbol,
        a.rating_avg,
        a.review_count,
        a.image_url,
        d.destination_id,
        d.city,
        d.country,
        c.name AS category_name,
        -- Score: base rating + bonus if matches interests + bonus if matches budget
        (
            COALESCE(a.rating_avg, 0) * 2
            + CASE
                WHEN v_interests IS NOT NULL
                 AND c.name IS NOT NULL
                 AND (
                       FIND_IN_SET('beach',     v_interests) > 0 AND c.name LIKE '%Beach%'
                    OR FIND_IN_SET('history',   v_interests) > 0 AND c.name LIKE '%Histor%'
                    OR FIND_IN_SET('culture',   v_interests) > 0 AND (c.name LIKE '%Cultur%' OR c.name LIKE '%Histor%')
                    OR FIND_IN_SET('adventure', v_interests) > 0 AND c.name LIKE '%Adventure%'
                    OR FIND_IN_SET('mountains', v_interests) > 0 AND c.name LIKE '%Adventure%'
                    OR FIND_IN_SET('food',      v_interests) > 0 AND a.type = 'restaurant'
                    OR FIND_IN_SET('shopping',  v_interests) > 0 AND a.name LIKE '%Mall%'
                 )
                THEN 3
                ELSE 0
              END
            + CASE
                WHEN v_budget IS NOT NULL AND a.price_range = v_budget THEN 2
                WHEN a.price_range = 'free'                            THEN 1
                ELSE 0
              END
        ) AS relevance_score
    FROM attractions a
    JOIN  destinations d ON d.destination_id = a.destination_id AND d.is_active = TRUE
    LEFT JOIN categories   c ON c.category_id    = a.category_id
    WHERE a.is_active = TRUE
      AND a.attraction_id NOT IN (
            SELECT COALESCE(attraction_id, 0)
            FROM   favorites
            WHERE  user_id = p_user_id
              AND  attraction_id IS NOT NULL
          )
    ORDER BY relevance_score DESC, a.rating_avg DESC, a.review_count DESC
    LIMIT 20;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_get_traveler_stats` (IN `p_user_id` INT)   BEGIN
    -- Main stats from view
    SELECT * FROM vw_traveler_stats WHERE user_id = p_user_id;

    -- Most visited destination (second result set)
    SELECT
        d.city,
        d.country,
        COUNT(ii.item_id) AS times_planned
    FROM itinerary_items ii
    JOIN itineraries      i  ON i.itinerary_id   = ii.itinerary_id
    JOIN destinations     d  ON d.destination_id = i.destination_id
    WHERE i.user_id = p_user_id
    GROUP BY d.destination_id
    ORDER BY times_planned DESC
    LIMIT 1;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_moderate_review` (IN `p_admin_id` INT, IN `p_review_id` INT, IN `p_new_status` ENUM('approved','rejected'))   BEGIN
    DECLARE v_attraction_id INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
    END;

    START TRANSACTION;
        SELECT attraction_id INTO v_attraction_id FROM reviews WHERE review_id = p_review_id;

        UPDATE reviews SET status = p_new_status WHERE review_id = p_review_id;

        -- Recalculate attraction rating if applicable
        IF v_attraction_id IS NOT NULL THEN
            UPDATE attractions
            SET rating_avg   = (SELECT ROUND(AVG(rating),2) FROM reviews WHERE attraction_id = v_attraction_id AND status = 'approved'),
                review_count = (SELECT COUNT(*)             FROM reviews WHERE attraction_id = v_attraction_id AND status = 'approved')
            WHERE attraction_id = v_attraction_id;
        END IF;

        INSERT INTO audit_log (user_id, action, table_name, record_id, new_value)
        VALUES (p_admin_id, CONCAT('REVIEW_', p_new_status), 'reviews', p_review_id, p_new_status);
    COMMIT;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_recalculate_all_ratings` ()   BEGIN
    DECLARE v_done         INT DEFAULT FALSE;
    DECLARE v_attraction_id INT;
    DECLARE v_new_avg      DECIMAL(3,2);
    DECLARE v_new_count    INT;

    -- Declare cursor over all active attractions
    DECLARE cur_attractions CURSOR FOR
        SELECT attraction_id FROM attractions WHERE is_active = TRUE;

    -- Handler: when no more rows, set flag
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;

    OPEN cur_attractions;

    rating_loop: LOOP
        FETCH cur_attractions INTO v_attraction_id;
        IF v_done THEN LEAVE rating_loop; END IF;

        -- Recalculate from approved reviews
        SELECT
            ROUND(AVG(rating), 2),
            COUNT(*)
        INTO v_new_avg, v_new_count
        FROM reviews
        WHERE attraction_id = v_attraction_id AND status = 'approved';

        -- Update with fresh values
        UPDATE attractions
        SET rating_avg   = COALESCE(v_new_avg, 0.00),
            review_count = COALESCE(v_new_count, 0)
        WHERE attraction_id = v_attraction_id;

    END LOOP;

    CLOSE cur_attractions;

    -- Log the maintenance action
    INSERT INTO audit_log (action, table_name, new_value)
    VALUES ('RECALCULATE_ALL_RATINGS', 'attractions',
            CONCAT('Processed at ', NOW()));

    SELECT 'Rating recalculation complete.' AS result;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_register_user` (IN `p_username` VARCHAR(50), IN `p_email` VARCHAR(100), IN `p_password` VARCHAR(255), IN `p_full_name` VARCHAR(100), OUT `p_user_id` INT, OUT `p_message` VARCHAR(200))   BEGIN
    DECLARE v_exists INT DEFAULT 0;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SET p_user_id = -1;
        SET p_message = 'Database error during registration.';
    END;

    START TRANSACTION;
        SELECT COUNT(*) INTO v_exists FROM users WHERE email = p_email OR username = p_username;
        IF v_exists > 0 THEN
            SET p_user_id = 0;
            SET p_message = 'Username or email already exists.';
            ROLLBACK;
        ELSE
            INSERT INTO users (username, email, password_hash, full_name)
            VALUES (p_username, p_email, p_password, p_full_name);
            SET p_user_id = LAST_INSERT_ID();
            SET p_message = 'User registered successfully.';
            COMMIT;
        END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_search_destinations` (IN `p_keyword` VARCHAR(100), IN `p_country` VARCHAR(100), IN `p_season` VARCHAR(50))   BEGIN
    SELECT
        d.destination_id,
        d.country,
        d.city,
        d.description,
        d.climate,
        d.best_visit_season,
        COUNT(DISTINCT a.attraction_id) AS attraction_count,
        ROUND(AVG(r.rating),2)          AS avg_rating
    FROM destinations d
    LEFT JOIN attractions a ON a.destination_id = d.destination_id AND a.is_active = TRUE
    LEFT JOIN reviews     r ON r.destination_id = d.destination_id AND r.status = 'approved'
    WHERE d.is_active = TRUE
      AND (p_keyword IS NULL OR d.city    LIKE CONCAT('%', p_keyword, '%')
                             OR d.country LIKE CONCAT('%', p_keyword, '%')
                             OR d.description LIKE CONCAT('%', p_keyword, '%'))
      AND (p_country IS NULL OR d.country = p_country)
      AND (p_season  IS NULL OR d.best_visit_season LIKE CONCAT('%', p_season, '%'))
    GROUP BY d.destination_id
    ORDER BY avg_rating DESC;
END$$

--
-- Functions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_get_season` (`p_month` TINYINT) RETURNS VARCHAR(20) CHARSET utf8mb4 COLLATE utf8mb4_unicode_ci DETERMINISTIC BEGIN
    RETURN CASE
        WHEN p_month IN (12, 1, 2) THEN 'Winter'
        WHEN p_month IN (3, 4, 5)  THEN 'Spring'
        WHEN p_month IN (6, 7, 8)  THEN 'Summer'
        WHEN p_month IN (9,10,11)  THEN 'Autumn'
        ELSE 'Unknown'
    END;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `fn_price_symbol` (`p_price_range` VARCHAR(20)) RETURNS VARCHAR(10) CHARSET utf8mb4 COLLATE utf8mb4_unicode_ci DETERMINISTIC BEGIN
    RETURN CASE p_price_range
        WHEN 'free'      THEN 'FREE'
        WHEN 'budget'    THEN '$'
        WHEN 'mid-range' THEN '$$'
        WHEN 'luxury'    THEN '$$$'
        ELSE '?'
    END;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `fn_traveler_level` (`p_user_id` INT) RETURNS VARCHAR(20) CHARSET utf8mb4 COLLATE utf8mb4_unicode_ci READS SQL DATA BEGIN
    DECLARE v_reviews INT DEFAULT 0;
    DECLARE v_trips   INT DEFAULT 0;
    DECLARE v_score   INT DEFAULT 0;

    SELECT COUNT(*) INTO v_reviews
    FROM reviews WHERE user_id = p_user_id AND status = 'approved';

    SELECT COUNT(*) INTO v_trips
    FROM itineraries WHERE user_id = p_user_id;

    SET v_score = v_reviews + (v_trips * 2);

    RETURN CASE
        WHEN v_score = 0        THEN 'Explorer'
        WHEN v_score < 5        THEN 'Adventurer'
        WHEN v_score < 10       THEN 'Globetrotter'
        WHEN v_score < 20       THEN 'Wanderer'
        ELSE                         'Legend'
    END;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `fn_trip_duration` (`p_start` DATE, `p_end` DATE) RETURNS INT(11) DETERMINISTIC BEGIN
    RETURN DATEDIFF(p_end, p_start) + 1;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `fn_user_itinerary_count` (`p_user_id` INT) RETURNS INT(11) READS SQL DATA BEGIN
    DECLARE v_count INT;
    SELECT COUNT(*) INTO v_count FROM itineraries WHERE user_id = p_user_id;
    RETURN v_count;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `attractions`
--

CREATE TABLE `attractions` (
  `attraction_id` int(11) NOT NULL,
  `destination_id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `name` varchar(200) NOT NULL,
  `type` enum('attraction','hotel','restaurant') NOT NULL,
  `description` text DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `price_range` enum('free','budget','mid-range','luxury') DEFAULT NULL,
  `rating_avg` decimal(3,2) DEFAULT 0.00,
  `review_count` int(11) DEFAULT 0,
  `image_url` varchar(500) DEFAULT NULL,
  `opening_hours` varchar(200) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `attractions`
--

INSERT INTO `attractions` (`attraction_id`, `destination_id`, `category_id`, `name`, `type`, `description`, `address`, `price_range`, `rating_avg`, `review_count`, `image_url`, `opening_hours`, `is_active`, `created_at`) VALUES
(1, 1, 1, 'Badshahi Mosque', 'attraction', '17th-century Mughal mosque, one of the world\'s largest.', 'The Mall, Lahore', 'free', 4.50, 2, NULL, '06:00-22:00', 1, '2026-05-09 15:13:56'),
(2, 1, 1, 'Lahore Fort', 'attraction', 'UNESCO World Heritage Mughal fort complex.', 'Fort Rd, Lahore', 'budget', 0.00, 0, NULL, '09:00-17:00', 1, '2026-05-09 15:13:56'),
(3, 1, 4, 'Pearl Continental Lahore', 'hotel', 'Five-star luxury hotel in central Lahore.', 'Shahrah-e-Quaid-e-Azam', 'luxury', 0.00, 0, NULL, NULL, 1, '2026-05-09 15:13:56'),
(4, 1, 7, 'Gawalmandi Food Street', 'restaurant', 'Famous street food hub with traditional cuisine.', 'Gawalmandi, Lahore', 'budget', 0.00, 0, NULL, '18:00-02:00', 1, '2026-05-09 15:13:56'),
(5, 2, 2, 'Clifton Beach', 'attraction', 'Popular sandy beach on the Arabian Sea.', 'Clifton, Karachi', 'free', 5.00, 1, NULL, 'Open 24h', 1, '2026-05-09 15:13:56'),
(6, 2, 1, 'Quaid-e-Azam Mausoleum', 'attraction', 'Marble mausoleum of Pakistan\'s founding father.', 'M.A. Jinnah Rd, Karachi', 'free', 0.00, 0, NULL, '06:00-22:00', 1, '2026-05-09 15:13:56'),
(7, 2, 4, 'Movenpick Hotel', 'hotel', 'Luxury hotel overlooking the Arabian Sea.', 'Club Rd, Karachi', 'luxury', 0.00, 0, NULL, NULL, 1, '2026-05-09 15:13:56'),
(8, 2, 6, 'BBQ Tonight', 'restaurant', 'Award-winning Pakistani BBQ restaurant.', 'Clifton, Karachi', 'mid-range', 0.00, 0, NULL, '18:00-01:00', 1, '2026-05-09 15:13:56'),
(9, 3, 2, 'Daman-e-Koh', 'attraction', 'Hilltop viewpoint with panoramic city views.', 'Margalla Hills, Islamabad', 'free', 0.00, 0, NULL, '07:00-22:00', 1, '2026-05-09 15:13:56'),
(10, 3, 4, 'Serena Hotel Islamabad', 'hotel', 'Elegant five-star hotel in the diplomatic enclave.', 'Khayaban-e-Suhrawardy', 'luxury', 0.00, 0, NULL, NULL, 1, '2026-05-09 15:13:56'),
(11, 4, 3, 'Rakaposhi Base Camp', 'attraction', 'Trek to the base of 7,788m Rakaposhi peak.', 'Hunza Valley', 'free', 0.00, 0, NULL, 'Daylight hours', 1, '2026-05-09 15:13:56'),
(12, 4, 5, 'Eagle\'s Nest Hotel', 'hotel', 'Iconic guesthouse with breathtaking valley views.', 'Duikar, Hunza', 'budget', 0.00, 0, NULL, NULL, 1, '2026-05-09 15:13:56'),
(13, 5, 1, 'Hagia Sophia', 'attraction', '6th-century Byzantine cathedral, now a mosque.', 'Sultanahmet, Istanbul', 'budget', 5.00, 1, NULL, '09:00-17:00', 1, '2026-05-09 15:13:56'),
(14, 5, 1, 'Topkapi Palace', 'attraction', 'Ottoman palace museum with imperial treasures.', 'Sultanahmet, Istanbul', 'mid-range', 0.00, 0, NULL, '09:00-17:00', 1, '2026-05-09 15:13:56'),
(15, 5, 6, 'Nusr-Et Steakhouse', 'restaurant', 'World-famous steakhouse by Salt Bae.', 'Etiler, Istanbul', 'luxury', 0.00, 0, NULL, '12:00-00:00', 1, '2026-05-09 15:13:56'),
(16, 6, 1, 'Burj Khalifa', 'attraction', 'World\'s tallest building with observation decks.', 'Downtown Dubai', 'mid-range', 4.00, 1, NULL, '10:00-22:00', 1, '2026-05-09 15:13:56'),
(17, 6, 2, 'Dubai Mall', 'attraction', 'Mega shopping and entertainment complex.', 'Financial Centre Rd, Dubai', 'free', 0.00, 0, NULL, '10:00-00:00', 1, '2026-05-09 15:13:56'),
(18, 6, 4, 'Atlantis The Palm', 'hotel', 'Iconic luxury resort on Palm Jumeirah.', 'Palm Jumeirah, Dubai', 'luxury', 0.00, 0, NULL, NULL, 1, '2026-05-09 15:13:56'),
(19, 7, 1, 'Tower of London', 'attraction', 'Historic castle and fortress on the Thames.', 'London EC3N 4AB', 'mid-range', 0.00, 0, NULL, '09:00-17:30', 1, '2026-05-09 15:13:56'),
(20, 7, 2, 'Hyde Park', 'attraction', 'Major park in Central London.', 'London', 'free', 0.00, 0, NULL, '05:00-00:00', 1, '2026-05-09 15:13:56'),
(21, 7, 4, 'The Ritz London', 'hotel', 'Iconic 5-star hotel in Piccadilly.', '150 Piccadilly, London', 'luxury', 0.00, 0, NULL, NULL, 1, '2026-05-09 15:13:56'),
(22, 7, 6, 'Gordon Ramsay Grill', 'restaurant', 'Signature dishes by the famous chef.', 'Grosvenor Square, London', 'luxury', 0.00, 0, NULL, '12:00-23:00', 1, '2026-05-09 15:13:56'),
(23, 8, 1, 'Senso-ji Temple', 'attraction', 'Tokyo\'s oldest Buddhist temple in Asakusa.', 'Asakusa, Tokyo', 'free', 0.00, 0, NULL, '06:00-17:00', 1, '2026-05-09 15:13:56'),
(24, 8, 2, 'Shibuya Crossing', 'attraction', 'World\'s busiest pedestrian crossing.', 'Shibuya, Tokyo', 'free', 0.00, 0, NULL, 'Open 24h', 1, '2026-05-09 15:13:56'),
(25, 8, 4, 'Park Hyatt Tokyo', 'hotel', 'Luxury hotel offering sweeping city views.', 'Shinjuku, Tokyo', 'luxury', 0.00, 0, NULL, NULL, 1, '2026-05-09 15:13:56'),
(26, 8, 7, 'Tsukiji Market', 'restaurant', 'Bustling market with fresh sushi.', 'Chuo City, Tokyo', 'mid-range', 0.00, 0, NULL, '05:00-14:00', 1, '2026-05-09 15:13:56');

-- --------------------------------------------------------

--
-- Table structure for table `attraction_photos`
--

CREATE TABLE `attraction_photos` (
  `photo_id` int(11) NOT NULL,
  `attraction_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `photo_url` varchar(500) NOT NULL,
  `caption` varchar(300) DEFAULT NULL,
  `is_primary` tinyint(1) DEFAULT 0,
  `upload_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Triggers `attraction_photos`
--
DELIMITER $$
CREATE TRIGGER `trg_set_primary_photo` BEFORE INSERT ON `attraction_photos` FOR EACH ROW BEGIN
    DECLARE v_count INT DEFAULT 0;
    SELECT COUNT(*) INTO v_count
    FROM attraction_photos WHERE attraction_id = NEW.attraction_id;

    IF v_count = 0 THEN
        SET NEW.is_primary = TRUE;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `audit_log`
--

CREATE TABLE `audit_log` (
  `log_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `table_name` varchar(100) DEFAULT NULL,
  `record_id` int(11) DEFAULT NULL,
  `old_value` text DEFAULT NULL,
  `new_value` text DEFAULT NULL,
  `logged_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `audit_log`
--

INSERT INTO `audit_log` (`log_id`, `user_id`, `action`, `table_name`, `record_id`, `old_value`, `new_value`, `logged_at`) VALUES
(1, 6, 'CREATE_ITINERARY', 'itineraries', 3, NULL, 'summer vacation', '2026-05-10 05:14:32'),
(2, 6, 'CREATE_ITINERARY', 'itineraries', 4, NULL, 'family vacation', '2026-05-10 05:16:30'),
(3, 6, 'ADD_ITINERARY_ITEM', 'itinerary_items', 6, NULL, NULL, '2026-05-10 05:16:47'),
(4, 6, 'ADD_ITINERARY_ITEM', 'itinerary_items', 7, NULL, NULL, '2026-05-10 05:17:12'),
(5, NULL, 'AUTO_REJECT_OLD_REVIEWS', 'reviews', NULL, NULL, '0 reviews auto-rejected at 2026-05-10 16:08:03', '2026-05-10 11:08:03'),
(6, NULL, 'WEEKLY_TOP_DESTINATION', 'destinations', 5, NULL, 'Istanbul — 2 favorites this week', '2026-05-10 11:08:03'),
(7, NULL, 'WEEKLY_TOP_DESTINATION', 'destinations', 1, NULL, 'Lahore — 1 favorites this week', '2026-05-10 11:08:03'),
(8, NULL, 'WEEKLY_TOP_DESTINATION', 'destinations', 6, NULL, 'Dubai — 1 favorites this week', '2026-05-10 11:08:03');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `type` enum('attraction','hotel','restaurant','destination') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `name`, `description`, `type`) VALUES
(1, 'Historical Sites', 'Ancient monuments and heritage', 'attraction'),
(2, 'Beach & Nature', 'Beaches, parks, and natural wonders', 'attraction'),
(3, 'Adventure Sports', 'Hiking, rafting, and outdoor thrills', 'attraction'),
(4, 'Luxury Hotels', 'Five star accommodation', 'hotel'),
(5, 'Budget Hotels', 'Affordable stays', 'hotel'),
(6, 'Fine Dining', 'Upscale restaurants', 'restaurant'),
(7, 'Street Food', 'Local street food spots', 'restaurant'),
(8, 'City Destinations', 'Major urban centres', 'destination');

-- --------------------------------------------------------

--
-- Table structure for table `destinations`
--

CREATE TABLE `destinations` (
  `destination_id` int(11) NOT NULL,
  `country` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `climate` varchar(100) DEFAULT NULL,
  `best_visit_season` varchar(100) DEFAULT NULL,
  `emergency_contact` varchar(255) DEFAULT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `destinations`
--

INSERT INTO `destinations` (`destination_id`, `country`, `city`, `description`, `climate`, `best_visit_season`, `emergency_contact`, `image_url`, `is_active`, `created_by`, `created_at`) VALUES
(1, 'Pakistan', 'Lahore', 'The cultural capital of Pakistan rich in Mughal history.', 'Semi-arid', 'October–March', '1122', NULL, 1, 1, '2026-05-09 15:13:56'),
(2, 'Pakistan', 'Karachi', 'Pakistan\'s largest city and financial hub on the Arabian Sea.', 'Tropical', 'November–February', '115', NULL, 1, 1, '2026-05-09 15:13:56'),
(3, 'Pakistan', 'Islamabad', 'The modern capital city nestled near the Margalla Hills.', 'Humid subtropical', 'March–May', '1122', NULL, 1, 1, '2026-05-09 15:13:56'),
(4, 'Pakistan', 'Hunza', 'Stunning mountain valley in Gilgit-Baltistan.', 'Alpine', 'April–October', '1122', NULL, 1, 1, '2026-05-09 15:13:56'),
(5, 'Turkey', 'Istanbul', 'Historic city bridging Europe and Asia on the Bosphorus.', 'Mediterranean', 'April–October', '155', NULL, 1, 1, '2026-05-09 15:13:56'),
(6, 'UAE', 'Dubai', 'Futuristic city known for luxury and record-breaking architecture.', 'Desert', 'November–March', '999', NULL, 1, 1, '2026-05-09 15:13:56'),
(7, 'UK', 'London', 'Historic and modern capital on the River Thames.', 'Temperate', 'May–September', '999', NULL, 1, 1, '2026-05-09 15:13:56'),
(8, 'Japan', 'Tokyo', 'Bustling metropolis blending neon-lit skyscrapers with historic temples.', 'Humid subtropical', 'March–May, Sep–Nov', '110', NULL, 1, 1, '2026-05-09 15:13:56');

-- --------------------------------------------------------

--
-- Table structure for table `destination_weather`
--

CREATE TABLE `destination_weather` (
  `weather_id` int(11) NOT NULL,
  `destination_id` int(11) NOT NULL,
  `month_number` tinyint(4) NOT NULL COMMENT '1=Jan, 12=Dec',
  `month_name` varchar(20) NOT NULL,
  `avg_temp_c` decimal(4,1) DEFAULT NULL,
  `avg_rainfall_mm` decimal(6,1) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL COMMENT 'e.g. Hot and dry, Perfect weather'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `destination_weather`
--

INSERT INTO `destination_weather` (`weather_id`, `destination_id`, `month_number`, `month_name`, `avg_temp_c`, `avg_rainfall_mm`, `description`) VALUES
(1, 1, 1, 'January', 12.5, 18.0, 'Cool and dry — ideal for sightseeing'),
(2, 1, 2, 'February', 15.0, 22.0, 'Mild with occasional rain'),
(3, 1, 3, 'March', 21.0, 30.0, 'Warm and pleasant'),
(4, 1, 4, 'April', 28.0, 20.0, 'Getting warm, low rain'),
(5, 1, 5, 'May', 34.0, 15.0, 'Hot — avoid midday outdoors'),
(6, 1, 6, 'June', 38.0, 35.0, 'Very hot with pre-monsoon showers'),
(7, 1, 7, 'July', 36.0, 85.0, 'Monsoon season — heavy rain'),
(8, 1, 8, 'August', 35.0, 70.0, 'Monsoon continues'),
(9, 1, 9, 'September', 32.0, 40.0, 'Cooling down, rain easing'),
(10, 1, 10, 'October', 26.0, 10.0, 'Best month — cool and dry'),
(11, 1, 11, 'November', 18.0, 8.0, 'Excellent — crisp and clear'),
(12, 1, 12, 'December', 13.0, 12.0, 'Cool winter — great for tourism'),
(13, 5, 1, 'January', 6.0, 90.0, 'Cold with possible snow'),
(14, 5, 4, 'April', 12.0, 46.0, 'Spring — mild and pleasant'),
(15, 5, 7, 'July', 26.0, 20.0, 'Hot and sunny — peak season'),
(16, 5, 10, 'October', 17.0, 55.0, 'Autumn — warm and comfortable');

-- --------------------------------------------------------

--
-- Table structure for table `favorites`
--

CREATE TABLE `favorites` (
  `favorite_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `destination_id` int(11) DEFAULT NULL,
  `attraction_id` int(11) DEFAULT NULL,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `favorites`
--

INSERT INTO `favorites` (`favorite_id`, `user_id`, `destination_id`, `attraction_id`, `added_at`) VALUES
(1, 3, 1, NULL, '2026-05-09 15:13:56'),
(2, 3, 5, NULL, '2026-05-09 15:13:56'),
(3, 4, 5, NULL, '2026-05-09 15:13:56'),
(4, 4, 6, NULL, '2026-05-09 15:13:56'),
(5, 3, NULL, 1, '2026-05-09 15:13:56'),
(6, 3, NULL, 5, '2026-05-09 15:13:56'),
(7, 4, NULL, 13, '2026-05-09 15:13:56'),
(8, 4, NULL, 16, '2026-05-09 15:13:56'),
(9, 6, NULL, 3, '2026-05-10 05:47:53');

-- --------------------------------------------------------

--
-- Table structure for table `itineraries`
--

CREATE TABLE `itineraries` (
  `itinerary_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `destination_id` int(11) DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `total_budget` decimal(10,2) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `itineraries`
--

INSERT INTO `itineraries` (`itinerary_id`, `user_id`, `destination_id`, `title`, `start_date`, `end_date`, `total_budget`, `notes`, `is_public`, `created_at`, `updated_at`) VALUES
(1, 3, 1, 'Lahore Cultural Weekend', '2025-12-20', '2025-12-22', 15000.00, NULL, 1, '2026-05-09 15:13:56', '2026-05-09 15:13:56'),
(2, 4, 5, 'Istanbul History Tour', '2026-03-10', '2026-03-17', 1200.00, NULL, 1, '2026-05-09 15:13:56', '2026-05-09 15:13:56'),
(3, 6, 8, 'summer vacation', NULL, NULL, 10000.00, NULL, 0, '2026-05-10 05:14:32', '2026-05-10 05:14:32'),
(4, 6, 8, 'family vacation', '2026-05-11', '2026-05-27', 30000.00, NULL, 0, '2026-05-10 05:16:30', '2026-05-10 05:16:30');

-- --------------------------------------------------------

--
-- Table structure for table `itinerary_items`
--

CREATE TABLE `itinerary_items` (
  `item_id` int(11) NOT NULL,
  `itinerary_id` int(11) NOT NULL,
  `attraction_id` int(11) DEFAULT NULL,
  `day_number` int(11) NOT NULL,
  `visit_time` time DEFAULT NULL,
  `duration_mins` int(11) DEFAULT NULL COMMENT 'planned duration in minutes',
  `notes` varchar(500) DEFAULT NULL,
  `order_in_day` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `itinerary_items`
--

INSERT INTO `itinerary_items` (`item_id`, `itinerary_id`, `attraction_id`, `day_number`, `visit_time`, `duration_mins`, `notes`, `order_in_day`) VALUES
(1, 1, 1, 1, '09:00:00', 120, 'Morning visit to Badshahi Mosque', 1),
(2, 1, 2, 1, '12:00:00', 150, 'Afternoon at Lahore Fort', 2),
(3, 1, 4, 1, '20:00:00', 90, 'Evening street food at Gawalmandi', 3),
(4, 2, 13, 1, '10:00:00', 180, 'Hagia Sophia – book tickets in advance', 1),
(5, 2, 14, 1, '14:00:00', 120, 'Topkapi Palace afternoon', 2),
(6, 4, 23, 1, '09:00:00', 60, '', 1),
(7, 4, 25, 1, '09:00:00', 60, '', 1);

--
-- Triggers `itinerary_items`
--
DELIMITER $$
CREATE TRIGGER `trg_log_itinerary_item` AFTER INSERT ON `itinerary_items` FOR EACH ROW BEGIN
    DECLARE v_user_id INT;
    SELECT user_id INTO v_user_id FROM itineraries WHERE itinerary_id = NEW.itinerary_id;

    INSERT INTO audit_log (user_id, action, table_name, record_id)
    VALUES (v_user_id, 'ADD_ITINERARY_ITEM', 'itinerary_items', NEW.item_id);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `review_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `attraction_id` int(11) DEFAULT NULL,
  `destination_id` int(11) DEFAULT NULL,
  `rating` tinyint(4) NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`review_id`, `user_id`, `attraction_id`, `destination_id`, `rating`, `title`, `content`, `status`, `created_at`, `updated_at`) VALUES
(1, 3, 1, NULL, 5, 'Breathtaking!', 'Badshahi Mosque is one of the most beautiful structures I have ever seen.', 'approved', '2026-05-09 15:13:56', '2026-05-09 15:13:56'),
(2, 4, 1, NULL, 4, 'A must-visit', 'Incredible architecture but gets crowded on weekends.', 'approved', '2026-05-09 15:13:56', '2026-05-09 15:13:56'),
(3, 3, 5, NULL, 5, 'Lovely beach', 'Great place to relax with family. Clean and well maintained.', 'approved', '2026-05-09 15:13:56', '2026-05-09 15:13:56'),
(4, 4, 13, NULL, 5, 'Hagia Sophia is magical', 'The history inside this building is overwhelming. Must visit.', 'approved', '2026-05-09 15:13:56', '2026-05-09 15:13:56'),
(5, 3, 16, NULL, 4, 'Amazing views', 'Burj Khalifa observation deck is worth every penny.', 'approved', '2026-05-09 15:13:56', '2026-05-09 15:13:56'),
(6, 4, 2, NULL, 4, 'Great fort', 'Rich history, well-preserved. Guides are informative.', 'pending', '2026-05-09 15:13:56', '2026-05-09 15:13:56');

--
-- Triggers `reviews`
--
DELIMITER $$
CREATE TRIGGER `trg_after_review_insert` AFTER INSERT ON `reviews` FOR EACH ROW BEGIN
    IF NEW.status = 'approved' AND NEW.attraction_id IS NOT NULL THEN
        UPDATE attractions
        SET rating_avg   = (SELECT ROUND(AVG(rating),2) FROM reviews WHERE attraction_id = NEW.attraction_id AND status = 'approved'),
            review_count = (SELECT COUNT(*)             FROM reviews WHERE attraction_id = NEW.attraction_id AND status = 'approved')
        WHERE attraction_id = NEW.attraction_id;
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_after_review_update` AFTER UPDATE ON `reviews` FOR EACH ROW BEGIN
    IF NEW.attraction_id IS NOT NULL AND (NEW.status != OLD.status) THEN
        UPDATE attractions
        SET rating_avg   = (SELECT ROUND(AVG(rating),2) FROM reviews WHERE attraction_id = NEW.attraction_id AND status = 'approved'),
            review_count = (SELECT COUNT(*)             FROM reviews WHERE attraction_id = NEW.attraction_id AND status = 'approved')
        WHERE attraction_id = NEW.attraction_id;
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_prevent_duplicate_review` BEFORE INSERT ON `reviews` FOR EACH ROW BEGIN
    DECLARE v_exists INT DEFAULT 0;

    IF NEW.attraction_id IS NOT NULL THEN
        SELECT COUNT(*) INTO v_exists
        FROM reviews
        WHERE user_id = NEW.user_id
          AND attraction_id = NEW.attraction_id;
    ELSEIF NEW.destination_id IS NOT NULL THEN
        SELECT COUNT(*) INTO v_exists
        FROM reviews
        WHERE user_id = NEW.user_id
          AND destination_id = NEW.destination_id;
    END IF;

    IF v_exists > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'You have already reviewed this place.';
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `role` enum('traveler','admin','content_manager','tourism_official') DEFAULT 'traveler',
  `budget_pref` enum('budget','mid-range','luxury') DEFAULT 'mid-range',
  `interests` varchar(500) DEFAULT NULL COMMENT 'comma-separated: beach,mountains,culture,food',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password_hash`, `full_name`, `role`, `budget_pref`, `interests`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@journeyhub.com', 'b8b8eb83374c0bf3b1c3224159f6119dbfff1b7ed6dfecdd80d4e8a895790a34', 'System Admin', 'admin', 'luxury', 'culture,history', 1, '2026-05-09 15:13:56', '2026-05-09 15:13:56'),
(2, 'content_mgr', 'content@journeyhub.com', '08f659aa029feda0f2562353efc76e021bccc22f31889270455e5b0647c796b5', 'Sara Content', 'content_manager', 'mid-range', 'food,culture', 1, '2026-05-09 15:13:56', '2026-05-09 15:13:56'),
(3, 'ali_traveler', 'ali@email.com', 'ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f', 'Ali Hassan', 'traveler', 'budget', 'beach,food', 1, '2026-05-09 15:13:56', '2026-05-09 15:13:56'),
(4, 'sara_travel', 'sara@email.com', 'ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f', 'Sara Ahmed', 'traveler', 'mid-range', 'mountains,culture', 1, '2026-05-09 15:13:56', '2026-05-09 15:13:56'),
(5, 'tourism_off', 'tourism@gov.pk', 'd868c291a9d8b9b53360b8391d33da5da2a40680bd4d4b9010eb0997b21bfba0', 'Tourism Official PK', 'tourism_official', 'mid-range', 'culture,history', 1, '2026-05-09 15:13:56', '2026-05-09 15:13:56'),
(6, 'hira05', 'hira.bashir.abbasi18@gmail.com', '$2y$10$QQIh6O6GPnQ7sA.8rOfkl.czeIyZyTkuWUlrWHIlnsPmokjX7iTOW', 'Hira Bashir', 'traveler', 'mid-range', 'beach,mountains,nature', 1, '2026-05-09 15:15:43', '2026-05-10 05:31:14');

--
-- Triggers `users`
--
DELIMITER $$
CREATE TRIGGER `trg_user_deactivated` AFTER UPDATE ON `users` FOR EACH ROW BEGIN
    IF OLD.is_active = TRUE AND NEW.is_active = FALSE THEN
        INSERT INTO audit_log (user_id, action, table_name, record_id, old_value, new_value)
        VALUES (NEW.user_id, 'USER_DEACTIVATED', 'users', NEW.user_id, 'active', 'inactive');
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user_activity_log`
--

CREATE TABLE `user_activity_log` (
  `activity_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action_type` enum('search','view_destination','view_attraction','add_favorite','remove_favorite','create_itinerary','add_itinerary_item','submit_review','login','logout') NOT NULL,
  `entity_type` varchar(50) DEFAULT NULL COMMENT 'destination, attraction, itinerary etc.',
  `entity_id` int(11) DEFAULT NULL COMMENT 'the ID of the thing they acted on',
  `search_query` varchar(500) DEFAULT NULL COMMENT 'stores search terms if action_type=search',
  `ip_address` varchar(45) DEFAULT NULL,
  `logged_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_approved_reviews`
-- (See below for the actual view)
--
CREATE TABLE `vw_approved_reviews` (
`review_id` int(11)
,`rating` tinyint(4)
,`title` varchar(200)
,`content` text
,`created_at` timestamp
,`username` varchar(50)
,`full_name` varchar(100)
,`reviewed_entity` varchar(200)
,`review_type` varchar(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_attraction_details`
-- (See below for the actual view)
--
CREATE TABLE `vw_attraction_details` (
`attraction_id` int(11)
,`name` varchar(200)
,`attraction_name` varchar(200)
,`type` enum('attraction','hotel','restaurant')
,`description` text
,`address` varchar(500)
,`price_range` enum('free','budget','mid-range','luxury')
,`price_symbol` varchar(10)
,`rating_avg` decimal(3,2)
,`review_count` int(11)
,`opening_hours` varchar(200)
,`image_url` varchar(500)
,`destination_id` int(11)
,`city` varchar(100)
,`country` varchar(100)
,`category_name` varchar(100)
,`category_id` int(11)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_destination_summary`
-- (See below for the actual view)
--
CREATE TABLE `vw_destination_summary` (
`destination_id` int(11)
,`country` varchar(100)
,`city` varchar(100)
,`description` text
,`climate` varchar(100)
,`best_visit_season` varchar(100)
,`emergency_contact` varchar(255)
,`total_attractions` bigint(21)
,`hotel_count` bigint(21)
,`restaurant_count` bigint(21)
,`sightseeing_count` bigint(21)
,`avg_destination_rating` decimal(6,2)
,`total_reviews` bigint(21)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_destination_weather_summary`
-- (See below for the actual view)
--
CREATE TABLE `vw_destination_weather_summary` (
`destination_id` int(11)
,`city` varchar(100)
,`country` varchar(100)
,`best_month` varchar(20)
,`min_temp` decimal(4,1)
,`max_temp` decimal(4,1)
,`avg_rainfall` decimal(7,1)
,`months_with_data` bigint(21)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_top_attractions`
-- (See below for the actual view)
--
CREATE TABLE `vw_top_attractions` (
`attraction_id` int(11)
,`name` varchar(200)
,`type` enum('attraction','hotel','restaurant')
,`price_range` enum('free','budget','mid-range','luxury')
,`rating_avg` decimal(3,2)
,`review_count` int(11)
,`city` varchar(100)
,`country` varchar(100)
,`rank_in_destination` bigint(21)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_traveler_stats`
-- (See below for the actual view)
--
CREATE TABLE `vw_traveler_stats` (
`user_id` int(11)
,`username` varchar(50)
,`full_name` varchar(100)
,`budget_pref` enum('budget','mid-range','luxury')
,`interests` varchar(500)
,`total_trips` bigint(21)
,`total_activities_planned` bigint(21)
,`total_reviews` bigint(21)
,`total_favorites` bigint(21)
,`avg_rating_given` decimal(5,1)
,`last_trip_created` timestamp
,`total_budget_planned` decimal(32,2)
,`days_since_joined` int(7)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_user_itineraries`
-- (See below for the actual view)
--
CREATE TABLE `vw_user_itineraries` (
`itinerary_id` int(11)
,`user_id` int(11)
,`username` varchar(50)
,`full_name` varchar(100)
,`title` varchar(200)
,`destination_city` varchar(100)
,`destination_country` varchar(100)
,`start_date` date
,`end_date` date
,`trip_days` int(8)
,`total_budget` decimal(10,2)
,`total_activities` bigint(21)
,`is_public` tinyint(1)
,`created_at` timestamp
);

-- --------------------------------------------------------

--
-- Structure for view `vw_approved_reviews`
--
DROP TABLE IF EXISTS `vw_approved_reviews`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_approved_reviews`  AS SELECT `r`.`review_id` AS `review_id`, `r`.`rating` AS `rating`, `r`.`title` AS `title`, `r`.`content` AS `content`, `r`.`created_at` AS `created_at`, `u`.`username` AS `username`, `u`.`full_name` AS `full_name`, coalesce(`a`.`name`,`d`.`city`) AS `reviewed_entity`, CASE WHEN `r`.`attraction_id` is not null THEN 'attraction' ELSE 'destination' END AS `review_type` FROM (((`reviews` `r` join `users` `u` on(`u`.`user_id` = `r`.`user_id`)) left join `attractions` `a` on(`a`.`attraction_id` = `r`.`attraction_id`)) left join `destinations` `d` on(`d`.`destination_id` = `r`.`destination_id`)) WHERE `r`.`status` = 'approved' ;

-- --------------------------------------------------------

--
-- Structure for view `vw_attraction_details`
--
DROP TABLE IF EXISTS `vw_attraction_details`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_attraction_details`  AS SELECT `a`.`attraction_id` AS `attraction_id`, `a`.`name` AS `name`, `a`.`name` AS `attraction_name`, `a`.`type` AS `type`, `a`.`description` AS `description`, `a`.`address` AS `address`, `a`.`price_range` AS `price_range`, `fn_price_symbol`(`a`.`price_range`) AS `price_symbol`, `a`.`rating_avg` AS `rating_avg`, `a`.`review_count` AS `review_count`, `a`.`opening_hours` AS `opening_hours`, `a`.`image_url` AS `image_url`, `d`.`destination_id` AS `destination_id`, `d`.`city` AS `city`, `d`.`country` AS `country`, `c`.`name` AS `category_name`, `c`.`category_id` AS `category_id` FROM ((`attractions` `a` join `destinations` `d` on(`d`.`destination_id` = `a`.`destination_id`)) left join `categories` `c` on(`c`.`category_id` = `a`.`category_id`)) WHERE `a`.`is_active` = 1 ;

-- --------------------------------------------------------

--
-- Structure for view `vw_destination_summary`
--
DROP TABLE IF EXISTS `vw_destination_summary`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_destination_summary`  AS SELECT `d`.`destination_id` AS `destination_id`, `d`.`country` AS `country`, `d`.`city` AS `city`, `d`.`description` AS `description`, `d`.`climate` AS `climate`, `d`.`best_visit_season` AS `best_visit_season`, `d`.`emergency_contact` AS `emergency_contact`, count(distinct `a`.`attraction_id`) AS `total_attractions`, count(distinct case when `a`.`type` = 'hotel' then `a`.`attraction_id` end) AS `hotel_count`, count(distinct case when `a`.`type` = 'restaurant' then `a`.`attraction_id` end) AS `restaurant_count`, count(distinct case when `a`.`type` = 'attraction' then `a`.`attraction_id` end) AS `sightseeing_count`, round(avg(`r`.`rating`),2) AS `avg_destination_rating`, count(distinct `r`.`review_id`) AS `total_reviews` FROM ((`destinations` `d` left join `attractions` `a` on(`a`.`destination_id` = `d`.`destination_id` and `a`.`is_active` = 1)) left join `reviews` `r` on(`r`.`destination_id` = `d`.`destination_id` and `r`.`status` = 'approved')) WHERE `d`.`is_active` = 1 GROUP BY `d`.`destination_id` ;

-- --------------------------------------------------------

--
-- Structure for view `vw_destination_weather_summary`
--
DROP TABLE IF EXISTS `vw_destination_weather_summary`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_destination_weather_summary`  AS SELECT `d`.`destination_id` AS `destination_id`, `d`.`city` AS `city`, `d`.`country` AS `country`, `w`.`month_name` AS `best_month`, min(`w`.`avg_temp_c`) AS `min_temp`, max(`w`.`avg_temp_c`) AS `max_temp`, round(avg(`w`.`avg_rainfall_mm`),1) AS `avg_rainfall`, count(`w`.`weather_id`) AS `months_with_data` FROM (`destinations` `d` left join `destination_weather` `w` on(`w`.`destination_id` = `d`.`destination_id`)) GROUP BY `d`.`destination_id`, `w`.`month_name` ;

-- --------------------------------------------------------

--
-- Structure for view `vw_top_attractions`
--
DROP TABLE IF EXISTS `vw_top_attractions`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_top_attractions`  AS SELECT `a`.`attraction_id` AS `attraction_id`, `a`.`name` AS `name`, `a`.`type` AS `type`, `a`.`price_range` AS `price_range`, `a`.`rating_avg` AS `rating_avg`, `a`.`review_count` AS `review_count`, `d`.`city` AS `city`, `d`.`country` AS `country`, rank() over ( partition by `d`.`destination_id` order by `a`.`rating_avg` desc,`a`.`review_count` desc) AS `rank_in_destination` FROM (`attractions` `a` join `destinations` `d` on(`d`.`destination_id` = `a`.`destination_id`)) WHERE `a`.`is_active` = 1 AND `a`.`review_count` > 0 ;

-- --------------------------------------------------------

--
-- Structure for view `vw_traveler_stats`
--
DROP TABLE IF EXISTS `vw_traveler_stats`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_traveler_stats`  AS SELECT `u`.`user_id` AS `user_id`, `u`.`username` AS `username`, `u`.`full_name` AS `full_name`, `u`.`budget_pref` AS `budget_pref`, `u`.`interests` AS `interests`, count(distinct `i`.`itinerary_id`) AS `total_trips`, count(distinct `ii`.`item_id`) AS `total_activities_planned`, count(distinct `r`.`review_id`) AS `total_reviews`, count(distinct `f`.`favorite_id`) AS `total_favorites`, round(avg(`r`.`rating`),1) AS `avg_rating_given`, max(`i`.`created_at`) AS `last_trip_created`, sum(`i`.`total_budget`) AS `total_budget_planned`, to_days(current_timestamp()) - to_days(`u`.`created_at`) AS `days_since_joined` FROM ((((`users` `u` left join `itineraries` `i` on(`i`.`user_id` = `u`.`user_id`)) left join `itinerary_items` `ii` on(`ii`.`itinerary_id` = `i`.`itinerary_id`)) left join `reviews` `r` on(`r`.`user_id` = `u`.`user_id` and `r`.`status` = 'approved')) left join `favorites` `f` on(`f`.`user_id` = `u`.`user_id`)) WHERE `u`.`role` = 'traveler' AND `u`.`is_active` = 1 GROUP BY `u`.`user_id` ;

-- --------------------------------------------------------

--
-- Structure for view `vw_user_itineraries`
--
DROP TABLE IF EXISTS `vw_user_itineraries`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_user_itineraries`  AS SELECT `i`.`itinerary_id` AS `itinerary_id`, `i`.`user_id` AS `user_id`, `u`.`username` AS `username`, `u`.`full_name` AS `full_name`, `i`.`title` AS `title`, `d`.`city` AS `destination_city`, `d`.`country` AS `destination_country`, `i`.`start_date` AS `start_date`, `i`.`end_date` AS `end_date`, to_days(`i`.`end_date`) - to_days(`i`.`start_date`) + 1 AS `trip_days`, `i`.`total_budget` AS `total_budget`, count(`ii`.`item_id`) AS `total_activities`, `i`.`is_public` AS `is_public`, `i`.`created_at` AS `created_at` FROM (((`itineraries` `i` join `users` `u` on(`u`.`user_id` = `i`.`user_id`)) left join `destinations` `d` on(`d`.`destination_id` = `i`.`destination_id`)) left join `itinerary_items` `ii` on(`ii`.`itinerary_id` = `i`.`itinerary_id`)) GROUP BY `i`.`itinerary_id` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attractions`
--
ALTER TABLE `attractions`
  ADD PRIMARY KEY (`attraction_id`),
  ADD KEY `destination_id` (`destination_id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `idx_attractions_type_rating` (`type`,`rating_avg`);
ALTER TABLE `attractions` ADD FULLTEXT KEY `ft_attraction_search` (`name`,`description`,`address`);

--
-- Indexes for table `attraction_photos`
--
ALTER TABLE `attraction_photos`
  ADD PRIMARY KEY (`photo_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `idx_photos_attraction` (`attraction_id`,`is_primary`);

--
-- Indexes for table `audit_log`
--
ALTER TABLE `audit_log`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `idx_audit_action` (`action`,`logged_at`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `destinations`
--
ALTER TABLE `destinations`
  ADD PRIMARY KEY (`destination_id`),
  ADD UNIQUE KEY `uq_city_country` (`city`,`country`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `idx_destinations_country` (`country`,`is_active`);
ALTER TABLE `destinations` ADD FULLTEXT KEY `ft_destination_search` (`city`,`country`,`description`);

--
-- Indexes for table `destination_weather`
--
ALTER TABLE `destination_weather`
  ADD PRIMARY KEY (`weather_id`),
  ADD UNIQUE KEY `uq_dest_month` (`destination_id`,`month_number`);

--
-- Indexes for table `favorites`
--
ALTER TABLE `favorites`
  ADD PRIMARY KEY (`favorite_id`),
  ADD UNIQUE KEY `uq_fav_dest` (`user_id`,`destination_id`),
  ADD UNIQUE KEY `uq_fav_attr` (`user_id`,`attraction_id`),
  ADD KEY `destination_id` (`destination_id`),
  ADD KEY `attraction_id` (`attraction_id`),
  ADD KEY `idx_favorites_user` (`user_id`);

--
-- Indexes for table `itineraries`
--
ALTER TABLE `itineraries`
  ADD PRIMARY KEY (`itinerary_id`),
  ADD KEY `destination_id` (`destination_id`),
  ADD KEY `idx_itineraries_user` (`user_id`,`created_at`);

--
-- Indexes for table `itinerary_items`
--
ALTER TABLE `itinerary_items`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `itinerary_id` (`itinerary_id`),
  ADD KEY `attraction_id` (`attraction_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`review_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `attraction_id` (`attraction_id`),
  ADD KEY `destination_id` (`destination_id`),
  ADD KEY `idx_reviews_status` (`status`,`created_at`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_activity_log`
--
ALTER TABLE `user_activity_log`
  ADD PRIMARY KEY (`activity_id`),
  ADD KEY `idx_activity_user` (`user_id`,`logged_at`),
  ADD KEY `idx_activity_type` (`action_type`,`logged_at`),
  ADD KEY `idx_activity_entity` (`entity_type`,`entity_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attractions`
--
ALTER TABLE `attractions`
  MODIFY `attraction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `attraction_photos`
--
ALTER TABLE `attraction_photos`
  MODIFY `photo_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `audit_log`
--
ALTER TABLE `audit_log`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `destinations`
--
ALTER TABLE `destinations`
  MODIFY `destination_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `destination_weather`
--
ALTER TABLE `destination_weather`
  MODIFY `weather_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `favorites`
--
ALTER TABLE `favorites`
  MODIFY `favorite_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `itineraries`
--
ALTER TABLE `itineraries`
  MODIFY `itinerary_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `itinerary_items`
--
ALTER TABLE `itinerary_items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_activity_log`
--
ALTER TABLE `user_activity_log`
  MODIFY `activity_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attractions`
--
ALTER TABLE `attractions`
  ADD CONSTRAINT `attractions_ibfk_1` FOREIGN KEY (`destination_id`) REFERENCES `destinations` (`destination_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `attractions_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE SET NULL;

--
-- Constraints for table `attraction_photos`
--
ALTER TABLE `attraction_photos`
  ADD CONSTRAINT `attraction_photos_ibfk_1` FOREIGN KEY (`attraction_id`) REFERENCES `attractions` (`attraction_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `attraction_photos_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `audit_log`
--
ALTER TABLE `audit_log`
  ADD CONSTRAINT `audit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `destinations`
--
ALTER TABLE `destinations`
  ADD CONSTRAINT `destinations_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `destination_weather`
--
ALTER TABLE `destination_weather`
  ADD CONSTRAINT `destination_weather_ibfk_1` FOREIGN KEY (`destination_id`) REFERENCES `destinations` (`destination_id`) ON DELETE CASCADE;

--
-- Constraints for table `favorites`
--
ALTER TABLE `favorites`
  ADD CONSTRAINT `favorites_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `favorites_ibfk_2` FOREIGN KEY (`destination_id`) REFERENCES `destinations` (`destination_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `favorites_ibfk_3` FOREIGN KEY (`attraction_id`) REFERENCES `attractions` (`attraction_id`) ON DELETE CASCADE;

--
-- Constraints for table `itineraries`
--
ALTER TABLE `itineraries`
  ADD CONSTRAINT `itineraries_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `itineraries_ibfk_2` FOREIGN KEY (`destination_id`) REFERENCES `destinations` (`destination_id`) ON DELETE SET NULL;

--
-- Constraints for table `itinerary_items`
--
ALTER TABLE `itinerary_items`
  ADD CONSTRAINT `itinerary_items_ibfk_1` FOREIGN KEY (`itinerary_id`) REFERENCES `itineraries` (`itinerary_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `itinerary_items_ibfk_2` FOREIGN KEY (`attraction_id`) REFERENCES `attractions` (`attraction_id`) ON DELETE SET NULL;

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`attraction_id`) REFERENCES `attractions` (`attraction_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reviews_ibfk_3` FOREIGN KEY (`destination_id`) REFERENCES `destinations` (`destination_id`) ON DELETE CASCADE;

--
-- Constraints for table `user_activity_log`
--
ALTER TABLE `user_activity_log`
  ADD CONSTRAINT `user_activity_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

DELIMITER $$
--
-- Events
--
CREATE DEFINER=`root`@`localhost` EVENT `evt_archive_old_pending_reviews` ON SCHEDULE EVERY 1 DAY STARTS '2026-05-10 16:08:03' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
    -- Auto-reject reviews pending for more than 30 days
    UPDATE reviews
    SET status = 'rejected'
    WHERE status = 'pending'
      AND created_at < DATE_SUB(NOW(), INTERVAL 30 DAY);

    -- Log how many were processed
    INSERT INTO audit_log (action, table_name, new_value)
    VALUES (
        'AUTO_REJECT_OLD_REVIEWS',
        'reviews',
        CONCAT(ROW_COUNT(), ' reviews auto-rejected at ', NOW())
    );
END$$

CREATE DEFINER=`root`@`localhost` EVENT `evt_weekly_popularity_snapshot` ON SCHEDULE EVERY 1 WEEK STARTS '2026-05-10 16:08:03' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
    INSERT INTO audit_log (action, table_name, record_id, new_value)
    SELECT
        'WEEKLY_TOP_DESTINATION',
        'destinations',
        d.destination_id,
        CONCAT(d.city, ' — ', COUNT(f.favorite_id), ' favorites this week')
    FROM favorites f
    JOIN destinations d ON d.destination_id = f.destination_id
    WHERE f.added_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    GROUP BY d.destination_id
    ORDER BY COUNT(f.favorite_id) DESC
    LIMIT 3;
END$$

DELIMITER ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
