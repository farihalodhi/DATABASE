<?php
// =============================================================
// api/users.php  –  User API
// Routes:
//   POST   /api/users.php?action=register
//   POST   /api/users.php?action=login
//   POST   /api/users.php?action=logout
//   GET    /api/users.php?action=profile
//   PUT    /api/users.php?action=update_profile
//   PUT    /api/users.php?action=change_password
//   GET    /api/users.php?action=all          (admin)
//   PUT    /api/users.php?action=toggle_status (admin)
//   PUT    /api/users.php?action=change_role   (admin)
//   DELETE /api/users.php?action=delete        (admin)
// =============================================================
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../models/UserModel.php';
require_once __DIR__ . '/../models/AdminModel.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$body   = getBody();
$model  = new UserModel();

switch ($action) {

    // ── REGISTER ─────────────────────────────────────────────
    case 'register':
        if ($method !== 'POST') jsonError('POST required', 405);

        $required = ['username', 'email', 'password'];
        foreach ($required as $f) {
            if (empty($body[$f])) jsonError("Field '$f' is required.");
        }
        if (!filter_var($body['email'], FILTER_VALIDATE_EMAIL)) {
            jsonError('Invalid email address.');
        }
        if (strlen($body['password']) < 6) {
            jsonError('Password must be at least 6 characters.');
        }

        $result = $model->register($body);
        if (!$result['success']) jsonError($result['error']);
        jsonSuccess(['user_id' => $result['user_id']], 'Registered successfully.');
        break;

    // ── LOGIN ─────────────────────────────────────────────────
    case 'login':
        if ($method !== 'POST') jsonError('POST required', 405);
        if (empty($body['email']) || empty($body['password'])) {
            jsonError('Email and password are required.');
        }

        $result = $model->login($body['email'], $body['password']);
        if (!$result['success']) jsonError($result['error'], 401);
        jsonSuccess($result['user'], 'Login successful.');
        break;

    // ── LOGOUT ────────────────────────────────────────────────
    case 'logout':
        logoutUser();
        jsonSuccess(null, 'Logged out.');
        break;

    // ── PROFILE ───────────────────────────────────────────────
    case 'profile':
        requireLogin();
        $userId = (int)($_GET['user_id'] ?? currentUserId());
        // Travelers can only see own profile; admin can see any
        if ($userId !== currentUserId() && currentRole() !== 'admin') {
            jsonError('Access denied.', 403);
        }
        $profile = $model->getProfile($userId);
        if (!$profile) jsonError('User not found.', 404);
        jsonSuccess($profile);
        break;

    // ── UPDATE PROFILE ────────────────────────────────────────
    case 'update_profile':
        requireLogin();
        if ($method !== 'PUT' && $method !== 'POST') jsonError('PUT required', 405);
        $ok = $model->updateProfile(currentUserId(), $body);
        if (!$ok) jsonError('Update failed.');
        jsonSuccess(null, 'Profile updated.');
        break;

    // ── CHANGE PASSWORD ───────────────────────────────────────
    case 'change_password':
        requireLogin();
        if (empty($body['old_password']) || empty($body['new_password'])) {
            jsonError('Both old and new passwords required.');
        }
        if (strlen($body['new_password']) < 6) jsonError('New password too short.');
        $result = $model->changePassword(currentUserId(), $body['old_password'], $body['new_password']);
        if (!$result['success']) jsonError($result['error']);
        jsonSuccess(null, 'Password changed.');
        break;

    // ── ALL USERS (admin) ─────────────────────────────────────
    case 'all':
        requireRole('admin');
        $role = $_GET['role'] ?? '';
        $users = $model->getAllUsers($role);
        jsonSuccess($users);
        break;

    // ── TOGGLE USER STATUS (admin) ───────────────────────────
    case 'toggle_status':
        requireRole('admin');
        if (empty($body['user_id'])) jsonError('user_id required.');
        $active = (bool)($body['is_active'] ?? true);
        $model->toggleUserStatus((int)$body['user_id'], $active);
        jsonSuccess(null, 'User status updated.');
        break;

    // ── CHANGE ROLE (admin) ───────────────────────────────────
    case 'change_role':
        requireRole('admin');
        if (empty($body['user_id']) || empty($body['role'])) {
            jsonError('user_id and role required.');
        }
        $adminModel = new AdminModel();
        $result = $adminModel->changeUserRole(currentUserId(), (int)$body['user_id'], $body['role']);
        if (!$result['success']) jsonError($result['error']);
        jsonSuccess(null, 'Role updated.');
        break;

    // ── DELETE USER (admin) ───────────────────────────────────
    case 'delete':
        requireRole('admin');
        if ($method !== 'DELETE' && $method !== 'POST') jsonError('DELETE required', 405);
        if (empty($body['user_id'])) jsonError('user_id required.');
        $result = $model->deleteUser(currentUserId(), (int)$body['user_id']);
        if (!$result['success']) jsonError($result['error']);
        jsonSuccess(null, 'User deleted.');
        break;

    default:
        jsonError('Unknown action.', 404);
}
