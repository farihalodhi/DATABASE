<?php
// =============================================================
// api/reviews.php
// Routes:
//   POST   ?action=post
//   GET    ?action=for_attraction&id=1
//   GET    ?action=for_destination&id=1
//   GET    ?action=mine
//   GET    ?action=stats&id=1
//   DELETE ?action=delete&id=1
//   GET    ?action=pending          (admin)
//   PUT    ?action=moderate         (admin)
// =============================================================
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../models/ReviewModel.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$body   = getBody();
$model  = new ReviewModel();

switch ($action) {

    case 'post':
        requireLogin();
        if (empty($body['rating'])) jsonError('rating is required.');
        $result = $model->post(currentUserId(), $body);
        if (!$result['success']) jsonError($result['error']);
        jsonSuccess(['review_id' => $result['review_id']], $result['message']);
        break;

    case 'for_attraction':
        $id = (int)($_GET['id'] ?? 0);
        if (!$id) jsonError('id required.');
        jsonSuccess($model->getForAttraction($id));
        break;

    case 'for_destination':
        $id = (int)($_GET['id'] ?? 0);
        if (!$id) jsonError('id required.');
        jsonSuccess($model->getForDestination($id));
        break;

    case 'mine':
        requireLogin();
        jsonSuccess($model->getUserReviews(currentUserId()));
        break;

    case 'stats':
        $id = (int)($_GET['id'] ?? 0);
        if (!$id) jsonError('id required.');
        jsonSuccess($model->getRatingStats($id));
        break;

    case 'delete':
        requireLogin();
        $id = (int)($_GET['id'] ?? $body['review_id'] ?? 0);
        if (!$id) jsonError('id required.');
        $ok = $model->deleteOwn($id, currentUserId());
        if (!$ok) jsonError('Review not found or access denied.', 404);
        jsonSuccess(null, 'Review deleted.');
        break;

    case 'pending':
        requireRole('admin');
        jsonSuccess($model->getPending());
        break;

    case 'moderate':
        requireRole('admin');
        if (empty($body['review_id']) || empty($body['status'])) {
            jsonError('review_id and status required.');
        }
        $result = $model->moderate(currentUserId(), (int)$body['review_id'], $body['status']);
        if (!$result['success']) jsonError($result['error']);
        jsonSuccess(null, $result['message']);
        break;

    default:
        jsonError('Unknown action.', 404);
}
