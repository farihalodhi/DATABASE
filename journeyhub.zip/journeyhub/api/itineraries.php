<?php
// =============================================================
// api/itineraries.php
// Routes:
//   GET    ?action=list            (own)
//   GET    ?action=get&id=1
//   GET    ?action=public
//   POST   ?action=create
//   PUT    ?action=update&id=1
//   POST   ?action=add_item
//   DELETE ?action=remove_item&item_id=5
//   DELETE ?action=delete&id=1
// =============================================================
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../models/ItineraryModel.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$body   = getBody();
$model  = new ItineraryModel();

switch ($action) {

    case 'list':
        requireLogin();
        $userId = (int)($_GET['user_id'] ?? currentUserId());
        if ($userId !== currentUserId()) {
            requireRole('admin');
        }
        jsonSuccess($model->getUserItineraries($userId));
        break;

    case 'get':
        requireLogin();
        $id = (int)($_GET['id'] ?? 0);
        if (!$id) jsonError('id required.');
        $itin = $model->getWithItems($id, currentUserId());
        if (!$itin) jsonError('Itinerary not found.', 404);
        jsonSuccess($itin);
        break;

    case 'public':
        $limit = (int)($_GET['limit'] ?? 20);
        jsonSuccess($model->getPublicFeed($limit));
        break;

    case 'admin_trips':
        $limit = (int)($_GET['limit'] ?? 6);
        jsonSuccess($model->getAdminItineraries($limit));
        break;

    case 'create':
        requireLogin();
        if (empty($body['title'])) jsonError('title is required.');
        requireCsrf();
        $result = $model->create(currentUserId(), $body);
        if (!$result['success']) jsonError($result['message']);
        jsonSuccess(['itinerary_id' => $result['itinerary_id']], $result['message']);
        break;

    case 'update':
        requireLogin();
        $id = (int)($_GET['id'] ?? $body['itinerary_id'] ?? 0);
        if (!$id) jsonError('id required.');
        requireCsrf();
        $result = $model->update($id, currentUserId(), $body);
        if (!$result['success']) jsonError($result['error']);
        jsonSuccess(null, 'Itinerary updated.');
        break;

    case 'add_item':
        requireLogin();
        if (empty($body['itinerary_id'])) jsonError('itinerary_id required.');
        requireCsrf();
        $result = $model->addItem((int)$body['itinerary_id'], currentUserId(), $body);
        if (!$result['success']) jsonError($result['error']);
        jsonSuccess(['item_id' => $result['item_id']], 'Item added.');
        break;

    case 'update_item':
        requireLogin();
        $itemId = (int)($_GET['item_id'] ?? $body['item_id'] ?? 0);
        if (!$itemId) jsonError('item_id required.');
        requireCsrf();
        $ok = $model->updateItem($itemId, currentUserId(), $body);
        if (!$ok) jsonError('Failed to update item.');
        jsonSuccess(null, 'Item updated.');
        break;

    case 'remove_item':
        requireLogin();
        $itemId = (int)($_GET['item_id'] ?? $body['item_id'] ?? 0);
        if (!$itemId) jsonError('item_id required.');
        requireCsrf();
        $ok = $model->removeItem($itemId, currentUserId());
        if (!$ok) jsonError('Item not found or access denied.', 404);
        jsonSuccess(null, 'Item removed.');
        break;

    case 'clone':
        requireLogin();
        $id = (int)($_GET['id'] ?? $body['itinerary_id'] ?? 0);
        if (!$id) jsonError('id required.');
        requireCsrf();
        $result = $model->clone($id, currentUserId());
        if (!$result['success']) jsonError($result['error']);
        jsonSuccess(['itinerary_id' => $result['itinerary_id']], 'Itinerary cloned successfully.');
        break;

    case 'complete':
        requireLogin();
        $id = (int)($_GET['id'] ?? $body['itinerary_id'] ?? 0);
        if (!$id) jsonError('id required.');
        requireCsrf();
        $res = $model->complete($id, currentUserId());
        if (!$res['success']) jsonError($res['error']);
        jsonSuccess($res['data'] ?? null, 'Trip marked as completed.');
        break;

    case 'delete':
        requireLogin();
        $id = (int)($_GET['id'] ?? $body['itinerary_id'] ?? 0);
        if (!$id) jsonError('id required.');
        requireCsrf();
        $ok = $model->delete($id, currentUserId());
        if (!$ok) jsonError('Itinerary not found or access denied.', 404);
        jsonSuccess(null, 'Itinerary deleted.');
        break;

    default:
        jsonError('Unknown action.', 404);
}
