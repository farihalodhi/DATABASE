<?php
// =============================================================
// api/destinations.php
// Routes:
//   GET    ?action=search&keyword=lahore&country=Pakistan
//   GET    ?action=get&id=1
//   GET    ?action=countries
//   GET    ?action=top
//   GET    ?action=attractions&id=1&type=hotel
//   POST   ?action=create      (content_manager/admin)
//   PUT    ?action=update&id=1 (content_manager/admin)
//   DELETE ?action=delete&id=1 (admin)
// =============================================================
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../models/DestinationModel.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$body   = getBody();
$model  = new DestinationModel();

switch ($action) {

    case 'search':
        $filters = [
            'keyword' => $_GET['keyword'] ?? '',
            'country' => $_GET['country'] ?? '',
            'season'  => $_GET['season']  ?? '',
        ];
        jsonSuccess($model->search($filters));
        break;

    case 'get':
        $id = (int)($_GET['id'] ?? 0);
        if (!$id) jsonError('id required.');
        $dest = $model->getById($id);
        if (!$dest) jsonError('Destination not found.', 404);
        jsonSuccess($dest);
        break;

    case 'countries':
        jsonSuccess($model->getCountries());
        break;

    case 'top':
        $limit = (int)($_GET['limit'] ?? 6);
        jsonSuccess($model->getTopDestinations($limit));
        break;

    case 'attractions':
        $id   = (int)($_GET['id']   ?? 0);
        $type = $_GET['type'] ?? '';
        if (!$id) jsonError('id required.');
        jsonSuccess($model->getAttractions($id, $type));
        break;
     
    case 'full_text_search':
        $query = trim($_GET['query'] ?? '');
        if ($query === '') jsonError('query is required.');
        jsonSuccess($model->fullTextSearch($query));
    break;    

    case 'create':
        requireRole('admin', 'content_manager');
        if ($method !== 'POST') jsonError('POST required', 405);
        if (empty($body['country']) || empty($body['city'])) {
            jsonError('country and city are required.');
        }
        $result = $model->create($body, currentUserId());
        if (!$result['success']) jsonError($result['error']);
        jsonSuccess(['destination_id' => $result['destination_id']], 'Destination created.');
        break;

    case 'update':
        requireRole('admin', 'content_manager');
        $id = (int)($_GET['id'] ?? $body['destination_id'] ?? 0);
        if (!$id) jsonError('id required.');
        $ok = $model->update($id, $body);
        if (!$ok) jsonError('Update failed.');
        jsonSuccess(null, 'Destination updated.');
        break;

    case 'delete':
        requireRole('admin');
        $id = (int)($_GET['id'] ?? $body['destination_id'] ?? 0);
        if (!$id) jsonError('id required.');
        $result = $model->deactivate($id, currentUserId());
        if (!$result['success']) jsonError($result['error']);
        jsonSuccess(null, 'Destination deactivated.');
        break;

    default:
        jsonError('Unknown action.', 404);
}
