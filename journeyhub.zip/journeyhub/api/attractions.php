<?php
// =============================================================
// api/attractions.php (FIXED VERSION)
// Routes:
//   GET  ?action=search&type=hotel&city=Lahore&price_range=budget
//   GET  ?action=get&id=1
//   GET  ?action=top_rated&dest_id=1
//   GET  ?action=above_average
//   GET  ?action=budget_friendly&city=Karachi
//   GET  ?action=dest_stats
//   POST ?action=create  (admin/content_manager)
//   PUT  ?action=update&id=1
//   DELETE ?action=delete&id=1
// =============================================================
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../models/AttractionModel.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$body   = getBody();
$model  = new AttractionModel();

switch ($action) {

    case 'search':
        $filters = [
            'type'        => $_GET['type']        ?? '',
            'price_range' => $_GET['price_range'] ?? '',
            'city'        => $_GET['city']        ?? '',
            'keyword'     => $_GET['keyword']     ?? '',
            'min_rating'  => $_GET['min_rating']  ?? '',
        ];
        jsonSuccess($model->search($filters));
        break;

    case 'get':
        $id = (int)($_GET['id'] ?? 0);
        if (!$id) jsonError('id required.');
        $attr = $model->getById($id);
        if (!$attr) jsonError('Attraction not found.', 404);
        jsonSuccess($attr);
        break;

    case 'top_rated':
        $destId = (int)($_GET['dest_id'] ?? 0);
        if (!$destId) jsonError('dest_id required.');
        jsonSuccess($model->getTopRated($destId));
        break;

    case 'above_average':
        jsonSuccess($model->getAboveAverage());
        break;

    case 'budget_friendly':
        jsonSuccess($model->getBudgetFriendly($_GET['city'] ?? ''));
        break;

    case 'dest_stats':
        jsonSuccess($model->getDestinationStats());
        break;

    case 'create':
        requireRole('admin', 'content_manager');
        if (empty($body['destination_id']) || empty($body['name']) || empty($body['type'])) {
            jsonError('destination_id, name, and type required.');
        }
        $result = $model->create($body);
        if (!$result['success']) jsonError($result['error']);
        jsonSuccess(['attraction_id' => $result['attraction_id']], 'Attraction created.');
        break;

    case 'update':
        requireRole('admin', 'content_manager');
        $id = (int)($_GET['id'] ?? $body['attraction_id'] ?? 0);
        if (!$id) jsonError('id required.');
        $ok = $model->update($id, $body);
        // ✅ FIXED: Now properly checks if update succeeded
        if (!$ok) jsonError('Update failed.');
        jsonSuccess(null, 'Attraction updated.');
        break;

    case 'delete':
        requireRole('admin');
        $id = (int)($_GET['id'] ?? $body['attraction_id'] ?? 0);
        if (!$id) jsonError('id required.');
        $model->deactivate($id);
        jsonSuccess(null, 'Attraction deactivated.');
        break;

    default:
        jsonError('Unknown action.', 404);
}