<?php
// =============================================================
// api/admin.php
// Routes (all require admin or tourism_official role):
//   GET  ?action=dashboard
//   GET  ?action=audit_log
//   GET  ?action=user_report
//   GET  ?action=incomplete_destinations
//   POST ?action=update_emergency
//   GET  ?action=recommendations&user_id=3
// =============================================================
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../models/AdminModel.php';
require_once __DIR__ . '/../models/DestinationModel.php';
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? '';
$body   = getBody();
$model  = new AdminModel();

switch ($action) {

    case 'dashboard':
        requireRole('admin');
        jsonSuccess($model->getDashboardStats());
        break;

    case 'audit_log':
        requireRole('admin');
        $filters = [
            'action'     => $_GET['filter_action'] ?? '',
            'table_name' => $_GET['table']         ?? '',
        ];
        jsonSuccess($model->getAuditLog($filters));
        break;

    case 'user_report':
        requireRole('admin');
        jsonSuccess($model->getActiveUsersReport());
        break;

    case 'incomplete_destinations':
        requireRole('admin', 'content_manager');
        jsonSuccess($model->getIncompleteDestinations());
        break;

    case 'update_emergency':
        requireRole('admin', 'tourism_official');
        if (empty($body['destination_id']) || empty($body['emergency_contact'])) {
            jsonError('destination_id and emergency_contact required.');
        }
        requireCsrf();
        $result = $model->updateEmergencyContact(
            (int)$body['destination_id'],
            $body['emergency_contact'],
            currentUserId()
        );
        if (!$result['success']) jsonError($result['error']);
        jsonSuccess(null, 'Emergency contact updated.');
        break;

    case 'recommendations':
        // GET ?action=recommendations&user_id=X
        // Returns personalised attraction recommendations for a user
        // by calling sp_get_recommendations stored procedure
        require_once __DIR__ . '/../models/RecommendationModel.php';
 
        $userId = (int)($_GET['user_id'] ?? currentUserId());
        if (!$userId) jsonError('user_id required.');
 
        // Any logged-in user can fetch their own recommendations.
        // Admins can fetch recommendations for any user.
        $currentId = currentUserId();
        if ($userId !== $currentId && !in_array(currentRole(), ['admin'])) {
            jsonError('Forbidden.', 403);
        }
 
        $model = new RecommendationModel();
        $recs  = $model->getForUser($userId);
        jsonSuccess($recs);
        break;

    default:
        jsonError('Unknown action.', 404);
}
