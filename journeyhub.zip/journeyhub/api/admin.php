<?php
// =============================================================
// api/admin.php
// Routes (all require admin or tourism_official role):
//   GET  ?action=dashboard
//   GET  ?action=audit_log
//   GET  ?action=user_report
//   GET  ?action=incomplete_destinations
//   POST ?action=update_emergency
//   GET  ?action=recommendations&user_id=3
// =============================================================
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../models/AdminModel.php';
require_once __DIR__ . '/../models/DestinationModel.php';
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? '';
$body   = getBody();
$model  = new AdminModel();

switch ($action) {

    case 'dashboard':
        requireRole('admin');
        jsonSuccess($model->getDashboardStats());
        break;

    case 'audit_log':
        requireRole('admin');
        $filters = [
            'action'     => $_GET['filter_action'] ?? '',
            'table_name' => $_GET['table']         ?? '',
        ];
        jsonSuccess($model->getAuditLog($filters));
        break;

    case 'user_report':
        requireRole('admin');
        jsonSuccess($model->getActiveUsersReport());
        break;

    case 'incomplete_destinations':
        requireRole('admin', 'content_manager');
        jsonSuccess($model->getIncompleteDestinations());
        break;

    case 'update_emergency':
        requireRole('admin', 'tourism_official');
        if (empty($body['destination_id']) || empty($body['emergency_contact'])) {
            jsonError('destination_id and emergency_contact required.');
        }
        $result = $model->updateEmergencyContact(
            (int)$body['destination_id'],
            $body['emergency_contact'],
            currentUserId()
        );
        if (!$result['success']) jsonError($result['error']);
        jsonSuccess(null, 'Emergency contact updated.');
        break;

    case 'recommendations':
        requireLogin();
        $userId = (int)($_GET['user_id'] ?? currentUserId());
        // Call stored procedure for personalised recommendations
        $db     = getDB();
        $stmt   = $db->prepare('CALL sp_get_recommendations(:uid)');
        $stmt->execute([':uid' => $userId]);
        $rows   = $stmt->fetchAll();
        jsonSuccess($rows);
        break;

    default:
        jsonError('Unknown action.', 404);
}
