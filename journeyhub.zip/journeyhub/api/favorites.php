<?php
// =============================================================
// api/favorites.php
// Routes:
//   POST   ?action=add
//   DELETE ?action=remove&fav_id=1
//   GET    ?action=list
//   GET    ?action=check&dest_id=1   OR &attr_id=1
//   GET    ?action=popular
// =============================================================
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../models/FavoriteModel.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$body   = getBody();
$model  = new FavoriteModel();

switch ($action) {

    case 'add':
        requireLogin();
        requireCsrf();
        $result = $model->add(currentUserId(), $body);
        if (!$result['success']) jsonError($result['error']);
        jsonSuccess(null, $result['message']);
        break;

    case 'remove':
        requireLogin();
        $favId = (int)($_GET['fav_id'] ?? $body['favorite_id'] ?? 0);
        if (!$favId) jsonError('fav_id required.');
        requireCsrf();
        $ok = $model->remove(currentUserId(), $favId);
        if (!$ok) jsonError('Favorite not found.', 404);
        jsonSuccess(null, 'Removed from favorites.');
        break;

    case 'list':
        requireLogin();
        jsonSuccess($model->getUserFavorites(currentUserId()));
        break;

    case 'check':
        requireLogin();
        $destId = !empty($_GET['dest_id']) ? (int)$_GET['dest_id'] : null;
        $attrId = !empty($_GET['attr_id']) ? (int)$_GET['attr_id'] : null;
        $result = $model->isFavorited(currentUserId(), $destId, $attrId);
        jsonSuccess(['is_favorited' => $result]);
        break;

    case 'popular':
        $limit = (int)($_GET['limit'] ?? 10);
        jsonSuccess($model->getMostFavorited($limit));
        break;

    default:
        jsonError('Unknown action.', 404);
}
