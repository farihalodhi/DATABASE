<?php
// =============================================================
// config/auth.php  – Session, Auth & Response Helpers (UPDATED)
// =============================================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ── JSON response helper ──────────────────────────────────────
function jsonResponse(array $data, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function jsonError(string $message, int $code = 400): void
{
    jsonResponse(['success' => false, 'error' => $message], $code);
}

function jsonSuccess($data = null, string $message = 'OK'): void
{
    $res = ['success' => true, 'message' => $message];
    if ($data !== null) $res['data'] = $data;
    jsonResponse($res, 200);
}

// ── Session helpers ───────────────────────────────────────────
function loginUser(array $user): void
{
    $_SESSION['user_id']  = $user['user_id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['role']     = $user['role'];
}

function logoutUser(): void
{
    session_unset();
    session_destroy();
}

function currentUserId(): ?int
{
    return $_SESSION['user_id'] ?? null;
}

function currentRole(): ?string
{
    return $_SESSION['role'] ?? null;
}

function isLoggedIn(): bool
{
    return isset($_SESSION['user_id']);
}

// ── Role guards ───────────────────────────────────────────────
function requireLogin(): void
{
    if (!isLoggedIn()) {
        jsonError('Authentication required. Please log in.', 401);
    }
}

function requireRole(string ...$roles): void
{
    requireLogin();
    if (!in_array(currentRole(), $roles, true)) {
        jsonError('Access denied. Insufficient permissions.', 403);
    }
}

// ── Input helpers ─────────────────────────────────────────────
function getBody(): array
{
    $contentType = $_SERVER["CONTENT_TYPE"] ?? '';

    if (strpos($contentType, 'application/json') !== false) {
        $raw = file_get_contents("php://input");
        return json_decode($raw, true) ?? [];
    }

    // fallback for form-data / x-www-form-urlencoded
    return $_POST;
}

// ── Password helpers ──────────────────────────────────────────
function hashPassword(string $plain): string
{
    return password_hash($plain, PASSWORD_BCRYPT);
}

function verifyPassword(string $plain, string $hash): bool
{
    return password_verify($plain, $hash);
}

// ── Sanitization helper ─────────────────────────────────────
// ✅ ADDED: This function was missing and used throughout the models
function sanitize(string $input = ''): string
{
    if (!is_string($input)) {
        return '';
    }
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}