<?php
// =============================================================
// config/db.php  – PDO Database Connection (FIXED VERSION)
// =============================================================

define('DB_HOST', 'localhost');
define('DB_NAME', 'journeyhub');
define('DB_USER', 'root');        // change to your MySQL username
define('DB_PASS', '');            // change to your MySQL password
define('DB_CHARSET', 'utf8mb4');

function getDB(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $dsn = sprintf(
            'mysql:host=%s;dbname=%s;charset=%s',
            DB_HOST, DB_NAME, DB_CHARSET
        );

        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];

        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // ✅ FIXED: Don't expose database error details to client
            // Log the actual error server-side
            error_log('Database Connection Error: ' . $e->getMessage());
            
            // Send generic error message to client
            http_response_code(500);
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'error' => 'Database connection failed. Please try again later.'
            ]);
            exit;
        }
    }

    return $pdo;
}