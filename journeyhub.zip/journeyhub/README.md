# JourneyHub – Travel Planning System
## Database Course Project | PHP + MySQL Backend

---

## Project Structure

```
journeyhub/
├── database/
│   └── journeyhub.sql          ← Full schema: tables, views, procs, triggers, data
├── config/
│   ├── db.php                  ← PDO connection (single shared instance)
│   └── auth.php                ← Session, auth guards, response helpers
├── models/
│   ├── UserModel.php           ← User CRUD + auth
│   ├── DestinationModel.php    ← Search + manage destinations
│   ├── AttractionModel.php     ← Attractions / hotels / restaurants
│   ├── ItineraryModel.php      ← Trip planning + items
│   ├── ReviewModel.php         ← Post, moderate, fetch reviews
│   ├── FavoriteModel.php       ← Save/remove favorites
│   └── AdminModel.php          ← Dashboard, audit log, reports
└── api/
    ├── users.php
    ├── destinations.php
    ├── attractions.php
    ├── itineraries.php
    ├── reviews.php
    ├── favorites.php
    └── admin.php
```

---

## How the Database & Backend are Connected

```
Browser / Postman (HTTP Request)
         │
         ▼
   api/users.php  (or any api/*.php)
         │  requires config/auth.php  (session + helpers)
         │  creates  models/UserModel.php
         │
         ▼
   Model class (e.g. UserModel)
         │  calls  getDB()  from config/db.php
         │
         ▼
   PDO $pdo  ──── DSN: mysql:host=localhost;dbname=journeyhub ────▶  MySQL Server
                  Uses prepared statements with named parameters (:param)
                  Returns results as PHP arrays (PDO::FETCH_ASSOC)
         │
         ▼
   JSON response sent back to caller
```

**Key connection details:**
- **Driver**: PDO (PHP Data Objects) — database-agnostic, supports prepared statements
- **Connection string**: `mysql:host=localhost;dbname=journeyhub;charset=utf8mb4`
- **Pattern**: Singleton — `getDB()` creates the PDO object once and reuses it across the request
- **Security**: All user input goes through PDO prepared statements → prevents SQL injection
- **Session**: PHP native sessions store `user_id` and `role` after login

---

## Database Schema (Normalized to BCNF)

### Tables

| # | Table             | Primary Key     | Description                              |
|---|-------------------|-----------------|------------------------------------------|
| 1 | `users`           | user_id         | All system users (travelers, admins …)   |
| 2 | `categories`      | category_id     | Attraction/hotel/restaurant categories  |
| 3 | `destinations`    | destination_id  | Countries + Cities                       |
| 4 | `attractions`     | attraction_id   | Attractions, hotels, restaurants         |
| 5 | `itineraries`     | itinerary_id    | User trip plans                          |
| 6 | `itinerary_items` | item_id         | Individual stops within an itinerary     |
| 7 | `reviews`         | review_id       | User ratings & reviews                   |
| 8 | `favorites`       | favorite_id     | Saved destinations / attractions         |
| 9 | `audit_log`       | log_id          | Admin action trail                       |

### Foreign Key Relationships

```
users ──────────────────┬──► itineraries.user_id
                        ├──► reviews.user_id
                        ├──► favorites.user_id
                        ├──► destinations.created_by
                        └──► audit_log.user_id

destinations ───────────┬──► attractions.destination_id
                        ├──► itineraries.destination_id
                        ├──► reviews.destination_id
                        └──► favorites.destination_id

attractions ────────────┬──► itinerary_items.attraction_id
                        ├──► reviews.attraction_id
                        └──► favorites.attraction_id

categories  ────────────└──► attractions.category_id

itineraries ────────────└──► itinerary_items.itinerary_id
```

---

## Entity-Relationship Diagram (Text)

```
┌─────────────┐         ┌──────────────────┐        ┌──────────────┐
│    USERS    │         │   DESTINATIONS   │        │  CATEGORIES  │
│─────────────│         │──────────────────│        │──────────────│
│ PK user_id  │         │ PK dest_id       │        │ PK cat_id    │
│ username    │         │ country          │        │ name         │
│ email       │         │ city             │        │ type         │
│ password    │         │ description      │        └──────┬───────┘
│ role        │         │ climate          │               │
│ budget_pref │         │ best_season      │               │ has
│ interests   │         │ emergency_contact│               │
└──────┬──────┘         │ FK created_by ──►│               ▼
       │                └────────┬─────────┘     ┌──────────────────┐
       │ creates                 │ has            │   ATTRACTIONS    │
       │                         │                │──────────────────│
       │                         └──────────────► │ PK attr_id       │
       │ plans                                    │ FK dest_id       │
       │                                          │ FK cat_id        │
       ▼                                          │ name             │
┌──────────────┐                                  │ type             │
│  ITINERARIES │                                  │ price_range      │
│──────────────│                                  │ rating_avg       │
│ PK itin_id   │                                  └────────┬─────────┘
│ FK user_id   │                                           │
│ FK dest_id   │                                           │
│ title        │                                           │
│ start_date   │        ┌──────────────────┐               │
│ end_date     │        │ ITINERARY_ITEMS  │               │
│ total_budget │        │──────────────────│               │
└──────┬───────┘        │ PK item_id       │               │
       │ contains       │ FK itin_id       │               │
       └───────────────►│ FK attr_id ──────┼───────────────┘
                        │ day_number       │
                        │ visit_time       │
                        │ duration_mins    │
                        └──────────────────┘

       ┌──────────────────────────────────────────────────────────┐
       │                      REVIEWS                             │
       │──────────────────────────────────────────────────────────│
       │ PK review_id   FK user_id   FK attr_id   FK dest_id      │
       │ rating   title   content   status(pending/approved/rejected)│
       └──────────────────────────────────────────────────────────┘

       ┌──────────────────────────────────────────────────────────┐
       │                      FAVORITES                           │
       │──────────────────────────────────────────────────────────│
       │ PK fav_id    FK user_id   FK dest_id   FK attr_id        │
       └──────────────────────────────────────────────────────────┘

       ┌──────────────────────────────────────────────────────────┐
       │                      AUDIT_LOG                           │
       │──────────────────────────────────────────────────────────│
       │ PK log_id    FK user_id   action   table_name   record_id│
       └──────────────────────────────────────────────────────────┘
```

---

## Normalization Summary

### 1NF – All tables have atomic values, no repeating groups
- `interests` stored as comma-separated string (acceptable for scope)
- All PKs defined, no multi-valued columns

### 2NF – No partial dependencies (all non-key attrs depend on full PK)
- `itinerary_items(item_id)` — day_number, notes depend on item_id not itin+attr
- `favorites(fav_id)` — added_at depends on full PK

### 3NF – No transitive dependencies
- Extracted `categories` from `attractions` (category name → description does not depend on attraction)
- `city`/`country` info in `destinations`, not duplicated in `attractions`
- User profile data stays in `users`, not copied to `itineraries`

### BCNF – Every determinant is a candidate key
- In `favorites`: UNIQUE(user_id, destination_id) and UNIQUE(user_id, attraction_id) enforce no anomalies
- In `reviews`: CONSTRAINT ensures each review targets exactly one entity type

---

## Views

| View                     | Purpose                                           |
|--------------------------|---------------------------------------------------|
| `vw_destination_summary` | Aggregated stats per destination (counts, ratings)|
| `vw_attraction_details`  | Joined view with destination + category names     |
| `vw_user_itineraries`    | Itinerary list with trip days, activity count     |
| `vw_approved_reviews`    | All approved reviews with user + entity info      |
| `vw_top_attractions`     | Window function RANK() per destination            |

---

## Stored Procedures & Functions

| Name                        | Type      | Used by          |
|-----------------------------|-----------|------------------|
| `sp_register_user`          | Procedure | UserModel        |
| `sp_create_itinerary`       | Procedure | ItineraryModel   |
| `sp_moderate_review`        | Procedure | ReviewModel      |
| `sp_search_destinations`    | Procedure | DestinationModel |
| `sp_get_recommendations`    | Procedure | admin.php        |
| `fn_trip_duration`          | Function  | ItineraryModel   |
| `fn_user_itinerary_count`   | Function  | UserModel        |
| `fn_price_symbol`           | Function  | AttractionModel  |

---

## Triggers

| Trigger                    | Event              | Action                                      |
|----------------------------|--------------------|---------------------------------------------|
| `trg_after_review_insert`  | AFTER INSERT reviews | Recalculate attraction rating_avg          |
| `trg_after_review_update`  | AFTER UPDATE reviews | Recalculate rating on status change        |
| `trg_user_deactivated`     | AFTER UPDATE users   | Log deactivation to audit_log              |

---

## SQL Features Demonstrated

| Feature                      | Location                                  |
|------------------------------|-------------------------------------------|
| INNER / LEFT JOIN            | All models                                |
| Subqueries                   | AttractionModel::getAboveAverage()        |
| GROUP BY + HAVING            | AttractionModel::getDestinationStats()    |
| Window Functions (RANK, SUM OVER) | vw_top_attractions, ReviewModel::getRatingStats() |
| Stored Procedures            | sp_register_user, sp_create_itinerary …   |
| User-defined Functions       | fn_trip_duration, fn_price_symbol …       |
| Triggers                     | trg_after_review_insert …                 |
| Transactions + Rollback      | ItineraryModel, AdminModel, UserModel     |
| UNION ALL                    | FavoriteModel::getUserFavorites()         |
| DATE_FORMAT, DATEDIFF, NOW() | UserModel::getProfile(), views            |
| COALESCE, CONCAT, UPPER      | Multiple models                           |
| Dynamic parameterized queries| All search methods                        |
| INSERT IGNORE                | FavoriteModel::add()                      |
| CHECK constraints            | reviews.rating, reviews target check      |

---

## Setup Instructions

1. **Import the database:**
   ```bash
   mysql -u root -p < database/journeyhub.sql
   ```

2. **Configure connection** in `config/db.php`:
   ```php
   define('DB_USER', 'your_mysql_user');
   define('DB_PASS', 'your_mysql_password');
   ```

3. **Place project** in your web server root (XAMPP: `htdocs/journeyhub`)

4. **Test an endpoint:**
   ```
   POST http://localhost/journeyhub/api/users.php?action=login
   Body: {"email":"ali@email.com","password":"password123"}
   ```

---

## Sample API Calls

```bash
# Register
POST /api/users.php?action=register
{"username":"john","email":"john@example.com","password":"pass123","full_name":"John Doe"}

# Login
POST /api/users.php?action=login
{"email":"admin@journeyhub.com","password":"admin2024"}

# Search destinations
GET /api/destinations.php?action=search&keyword=lahore

# Create itinerary
POST /api/itineraries.php?action=create
{"title":"My Lahore Trip","destination_id":1,"start_date":"2025-12-20","end_date":"2025-12-22","total_budget":15000}

# Post a review
POST /api/reviews.php?action=post
{"attraction_id":1,"rating":5,"title":"Amazing!","content":"Absolutely beautiful mosque."}

# Admin: moderate review
PUT /api/reviews.php?action=moderate
{"review_id":6,"status":"approved"}

# Get personalised recommendations
GET /api/admin.php?action=recommendations
```
