<?php
// =============================================================
// setup/load_sample_data.php
// 
// This script generates proper bcrypt hashes for sample users
// and inserts them into the database with correct passwords.
//
// Usage: Run from command line or browser:
//   php setup/load_sample_data.php
// =============================================================

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';

echo "=== JourneyHub Sample Data Setup ===\n\n";

try {
    $db = getDB();
    
    // Sample user data with plaintext passwords
    $sampleUsers = [
        [
            'username' => 'admin',
            'email' => 'admin@journeyhub.com',
            'password' => 'admin2024',
            'full_name' => 'System Admin',
            'role' => 'admin',
            'budget_pref' => 'luxury',
            'interests' => 'culture,history'
        ],
        [
            'username' => 'content_mgr',
            'email' => 'content@journeyhub.com',
            'password' => 'content2024',
            'full_name' => 'Sara Content',
            'role' => 'content_manager',
            'budget_pref' => 'mid-range',
            'interests' => 'food,culture'
        ],
        [
            'username' => 'ali_traveler',
            'email' => 'ali@email.com',
            'password' => 'password123',
            'full_name' => 'Ali Hassan',
            'role' => 'traveler',
            'budget_pref' => 'budget',
            'interests' => 'beach,food'
        ],
        [
            'username' => 'sara_travel',
            'email' => 'sara@email.com',
            'password' => 'password123',
            'full_name' => 'Sara Ahmed',
            'role' => 'traveler',
            'budget_pref' => 'mid-range',
            'interests' => 'mountains,culture'
        ],
        [
            'username' => 'tourism_off',
            'email' => 'tourism@gov.pk',
            'password' => 'tourism2024',
            'full_name' => 'Tourism Official PK',
            'role' => 'tourism_official',
            'budget_pref' => 'mid-range',
            'interests' => 'culture,history'
        ]
    ];

    // Check if users already exist
    $stmt = $db->prepare('SELECT COUNT(*) as cnt FROM users');
    $stmt->execute();
    $result = $stmt->fetch();
    
    if ($result['cnt'] > 0) {
        echo "⚠️  Users already exist in database. Skipping insertion.\n";
        echo "To reset, run: DELETE FROM users WHERE user_id > 0;\n\n";
    } else {
        echo "📝 Inserting sample users with proper bcrypt hashes...\n\n";
        
        $stmt = $db->prepare(
            'INSERT INTO users (username, email, password_hash, full_name, role, budget_pref, interests)
             VALUES (:username, :email, :password_hash, :full_name, :role, :budget_pref, :interests)'
        );

        foreach ($sampleUsers as $user) {
            $hashedPassword = hashPassword($user['password']);
            
            $stmt->execute([
                ':username' => $user['username'],
                ':email' => $user['email'],
                ':password_hash' => $hashedPassword,
                ':full_name' => $user['full_name'],
                ':role' => $user['role'],
                ':budget_pref' => $user['budget_pref'],
                ':interests' => $user['interests']
            ]);
            
            echo "✅ Added: {$user['username']} ({$user['full_name']})\n";
        }

        echo "\n📋 Test Credentials:\n";
        echo "────────────────────────────────────────\n";
        foreach ($sampleUsers as $user) {
            echo "{$user['email']} : {$user['password']}\n";
        }
        echo "────────────────────────────────────────\n";
    }

    echo "\n✨ Setup complete!\n";
    echo "Your application is ready to use.\n";

} catch (PDOException $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    exit(1);
}