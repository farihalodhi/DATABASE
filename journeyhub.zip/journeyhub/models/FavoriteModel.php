<?php
// =============================================================
// models/FavoriteModel.php
// =============================================================
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';

class FavoriteModel
{
    private PDO $db;

    public function __construct()
    {
        $this->db = getDB();
    }

    // ── Add to favorites ──────────────────────────────────────
    public function add(int $userId, array $data): array
    {
        $hasAttr = !empty($data['attraction_id']);
        $hasDest = !empty($data['destination_id']);

        if (!$hasAttr && !$hasDest) {
            return ['success' => false, 'error' => 'Provide attraction_id or destination_id.'];
        }

        try {
            $stmt = $this->db->prepare(
                'INSERT IGNORE INTO favorites (user_id, destination_id, attraction_id)
                 VALUES (:uid,:did,:aid)'
            );
            $stmt->execute([
                ':uid' => $userId,
                ':did' => $hasDest ? (int)$data['destination_id'] : null,
                ':aid' => $hasAttr ? (int)$data['attraction_id']  : null,
            ]);
            return ['success' => true, 'message' => 'Added to favorites.'];
        } catch (PDOException $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    // ── Remove from favorites ─────────────────────────────────
    public function remove(int $userId, int $favoriteId): bool
    {
        $stmt = $this->db->prepare(
            'DELETE FROM favorites WHERE favorite_id = :fid AND user_id = :uid'
        );
        $stmt->execute([':fid' => $favoriteId, ':uid' => $userId]);
        return $stmt->rowCount() > 0;
    }

    // ── Get user's favorites (destinations + attractions) ─────
    // Uses: LEFT JOIN, UNION, COALESCE, CONCAT
    public function getUserFavorites(int $userId): array
    {
        $stmt = $this->db->prepare(
            "SELECT f.favorite_id, f.added_at,
                    'destination'    AS fav_type,
                    d.destination_id AS entity_id,
                    CONCAT(d.city,', ',d.country) AS entity_name,
                    d.description    AS entity_description,
                    NULL             AS entity_rating
             FROM favorites f
             JOIN destinations d ON d.destination_id = f.destination_id
             WHERE f.user_id = :uid1 AND f.destination_id IS NOT NULL

             UNION ALL

             SELECT f.favorite_id, f.added_at,
                    'attraction'     AS fav_type,
                    a.attraction_id  AS entity_id,
                    a.name           AS entity_name,
                    a.description    AS entity_description,
                    a.rating_avg     AS entity_rating
             FROM favorites f
             JOIN attractions a ON a.attraction_id = f.attraction_id
             WHERE f.user_id = :uid2 AND f.attraction_id IS NOT NULL

             ORDER BY added_at DESC"
        );
        $stmt->execute([':uid1' => $userId, ':uid2' => $userId]);
        return $stmt->fetchAll();
    }

    // ── Check if entity is already favorited ─────────────────
    public function isFavorited(int $userId, ?int $destId, ?int $attrId): bool
    {
        if ($destId) {
            $stmt = $this->db->prepare(
                'SELECT favorite_id FROM favorites WHERE user_id = :uid AND destination_id = :did'
            );
            $stmt->execute([':uid' => $userId, ':did' => $destId]);
        } else {
            $stmt = $this->db->prepare(
                'SELECT favorite_id FROM favorites WHERE user_id = :uid AND attraction_id = :aid'
            );
            $stmt->execute([':uid' => $userId, ':aid' => $attrId]);
        }
        return (bool)$stmt->fetch();
    }

    // ── Most favorited destinations (analytics) ───────────────
    public function getMostFavorited(int $limit = 10): array
    {
        $stmt = $this->db->prepare(
            "SELECT d.destination_id, CONCAT(d.city,', ',d.country) AS destination,
                    COUNT(f.favorite_id) AS favorite_count
             FROM favorites f
             JOIN destinations d ON d.destination_id = f.destination_id
             GROUP BY f.destination_id
             ORDER BY favorite_count DESC
             LIMIT :lim"
        );
        $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
