<?php
// =============================================================
// models/DestinationModel.php
// =============================================================
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';

class DestinationModel
{
    private PDO $db;

    public function __construct()
    {
        $this->db = getDB();
    }

    // ── Search destinations (traveler) ────────────────────────
    // Uses: LIKE, GROUP BY, AVG, COUNT, JOIN, dynamic input
    public function search(array $filters): array
    {
        $sql = "SELECT d.destination_id, d.country, d.city,
                       d.description, d.climate, d.best_visit_season,
                       d.emergency_contact,
                       COUNT(DISTINCT a.attraction_id)              AS attraction_count,
                       ROUND(AVG(r.rating), 2)                      AS avg_rating,
                       COUNT(DISTINCT r.review_id)                  AS review_count
                FROM destinations d
                LEFT JOIN attractions a ON a.destination_id = d.destination_id AND a.is_active = TRUE
                LEFT JOIN reviews     r ON r.destination_id = d.destination_id AND r.status = 'approved'
                WHERE d.is_active = TRUE";

        $params = [];

        if (!empty($filters['keyword'])) {
            $sql .= " AND (d.city LIKE :kw1 OR d.country LIKE :kw2 OR d.description LIKE :kw3)";
            $params[':kw1'] = '%' . $filters['keyword'] . '%';
            $params[':kw2'] = '%' . $filters['keyword'] . '%';
            $params[':kw3'] = '%' . $filters['keyword'] . '%';
        }
        if (!empty($filters['country'])) {
            $sql .= " AND d.country = :country";
            $params[':country'] = $filters['country'];
        }
        if (!empty($filters['season'])) {
            $sql .= " AND d.best_visit_season LIKE :season";
            $params[':season'] = '%' . $filters['season'] . '%';
        }

        $sql .= " GROUP BY d.destination_id ORDER BY avg_rating DESC, attraction_count DESC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    // ── Get single destination (uses view) ───────────────────
    public function getById(int $id): ?array
    {
        $stmt = $this->db->prepare(
            'SELECT * FROM vw_destination_summary WHERE destination_id = :id'
        );
        $stmt->execute([':id' => $id]);
        return $stmt->fetch() ?: null;
    }

    // ── Get all countries (for filter dropdown) ───────────────
    public function getCountries(): array
    {
        $stmt = $this->db->query(
            'SELECT DISTINCT country FROM destinations WHERE is_active = TRUE ORDER BY country'
        );
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    // ── Get attractions for a destination ─────────────────────
    // Uses: INNER JOIN, category, fn_price_symbol
    public function getAttractions(int $destId, string $type = ''): array
    {
        $sql = "SELECT a.attraction_id, a.name, a.type, a.description,
                       a.address, a.price_range, fn_price_symbol(a.price_range) AS price_symbol,
                       a.rating_avg, a.review_count, a.opening_hours,
                       c.name AS category_name
                FROM attractions a
                LEFT JOIN categories c ON c.category_id = a.category_id
                WHERE a.destination_id = :did AND a.is_active = TRUE";
        $params = [':did' => $destId];

        if ($type) {
            $sql .= " AND a.type = :type";
            $params[':type'] = $type;
        }

        $sql .= " ORDER BY a.rating_avg DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    // ── Add destination (content_manager / admin) ─────────────
    public function create(array $data, int $createdBy): array
    {
        try {
            $this->db->beginTransaction();

            $stmt = $this->db->prepare(
                'INSERT INTO destinations
                 (country, city, description, climate, best_visit_season, emergency_contact, created_by)
                 VALUES (:co,:ci,:de,:cl,:bs,:ec,:cb)'
            );
            $stmt->execute([
                ':co' => sanitize($data['country']),
                ':ci' => sanitize($data['city']),
                ':de' => sanitize($data['description'] ?? ''),
                ':cl' => sanitize($data['climate'] ?? ''),
                ':bs' => sanitize($data['best_visit_season'] ?? ''),
                ':ec' => sanitize($data['emergency_contact'] ?? ''),
                ':cb' => $createdBy,
            ]);
            $newId = (int)$this->db->lastInsertId();

            // Audit log
            $this->db->prepare(
                "INSERT INTO audit_log (user_id, action, table_name, record_id, new_value)
                 VALUES (:uid,'ADD_DESTINATION','destinations',:rid,:val)"
            )->execute([':uid' => $createdBy, ':rid' => $newId, ':val' => $data['city'] . ', ' . $data['country']]);

            $this->db->commit();
            return ['success' => true, 'destination_id' => $newId];
        } catch (PDOException $e) {
            $this->db->rollBack();
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    // ── Update destination ────────────────────────────────────
    public function update(int $id, array $data): bool
    {
        $stmt = $this->db->prepare(
            'UPDATE destinations
             SET description = :de, climate = :cl, best_visit_season = :bs, emergency_contact = :ec
             WHERE destination_id = :id'
        );
        return $stmt->execute([
            ':de' => sanitize($data['description'] ?? ''),
            ':cl' => sanitize($data['climate'] ?? ''),
            ':bs' => sanitize($data['best_visit_season'] ?? ''),
            ':ec' => sanitize($data['emergency_contact'] ?? ''),
            ':id' => $id,
        ]);
    }

    // ── Soft-delete (deactivate) ──────────────────────────────
    public function deactivate(int $id, int $adminId): array
    {
        try {
            $this->db->beginTransaction();

            $this->db->prepare('UPDATE destinations SET is_active = FALSE WHERE destination_id = :id')
                     ->execute([':id' => $id]);

            $this->db->prepare(
                "INSERT INTO audit_log (user_id, action, table_name, record_id)
                 VALUES (:uid,'DEACTIVATE_DESTINATION','destinations',:rid)"
            )->execute([':uid' => $adminId, ':rid' => $id]);

            $this->db->commit();
            return ['success' => true];
        } catch (PDOException $e) {
            $this->db->rollBack();
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    // ── Top destinations by review count (dashboard) ──────────
    // Uses: SUBQUERY, ORDER BY, LIMIT
    public function getTopDestinations(int $limit = 6): array
    {
        $stmt = $this->db->prepare(
            "SELECT destination_id, country, city, avg_destination_rating, total_reviews, total_attractions
             FROM vw_destination_summary
             WHERE total_reviews > 0
             ORDER BY avg_destination_rating DESC, total_reviews DESC
             LIMIT :lim"
        );
        $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
