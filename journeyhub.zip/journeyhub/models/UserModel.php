<?php
// =============================================================
// models/UserModel.php
// =============================================================
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';

class UserModel
{
    private PDO $db;

    public function __construct()
    {
        $this->db = getDB();
    }

    // ── Register new user ─────────────────────────────────────
    public function register(array $data): array
    {
        // Check duplicate email / username
        $stmt = $this->db->prepare(
            'SELECT user_id FROM users WHERE email = :email OR username = :username'
        );
        $stmt->execute([':email' => $data['email'], ':username' => $data['username']]);
        if ($stmt->fetch()) {
            return ['success' => false, 'error' => 'Username or email already taken.'];
        }

        $stmt = $this->db->prepare(
            'INSERT INTO users (username, email, password_hash, full_name, budget_pref, interests)
             VALUES (:u, :e, :p, :f, :b, :i)'
        );
        $stmt->execute([
            ':u' => sanitize($data['username']),
            ':e' => filter_var($data['email'], FILTER_SANITIZE_EMAIL),
            ':p' => hashPassword($data['password']),
            ':f' => sanitize($data['full_name'] ?? ''),
            ':b' => $data['budget_pref'] ?? 'mid-range',
            ':i' => sanitize($data['interests'] ?? ''),
        ]);

        return ['success' => true, 'user_id' => (int)$this->db->lastInsertId()];
    }

    // ── Login ─────────────────────────────────────────────────
    public function login(string $email, string $password): array
    {
        $stmt = $this->db->prepare(
            'SELECT user_id, username, email, password_hash, full_name, role, is_active
             FROM users WHERE email = :email'
        );
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch();

        if (!$user || !verifyPassword($password, $user['password_hash'])) {
            return ['success' => false, 'error' => 'Invalid email or password.'];
        }
        if (!$user['is_active']) {
            return ['success' => false, 'error' => 'Account has been deactivated.'];
        }

        unset($user['password_hash']);
        loginUser($user);
        return ['success' => true, 'user' => $user];
    }

    // ── Get profile ───────────────────────────────────────────
    public function getProfile(int $userId): ?array
    {
        // Uses: DATE_FORMAT, DATEDIFF, subqueries for itinerary count and traveler level
        $stmt = $this->db->prepare(
            "SELECT u.user_id, u.username, u.email, u.full_name, u.role, u.budget_pref, u.interests,
                    DATE_FORMAT(u.created_at,'%d %M %Y')      AS member_since,
                    DATEDIFF(NOW(), u.created_at)             AS days_since_joined,
                    (SELECT COUNT(*) FROM itineraries WHERE user_id = u.user_id) AS total_itineraries,
                    (
                        SELECT CASE 
                            WHEN (COUNT(r.review_id) + (COUNT(DISTINCT i.itinerary_id) * 2)) = 0  THEN 'Explorer'
                            WHEN (COUNT(r.review_id) + (COUNT(DISTINCT i.itinerary_id) * 2)) < 5  THEN 'Adventurer'
                            WHEN (COUNT(r.review_id) + (COUNT(DISTINCT i.itinerary_id) * 2)) < 10 THEN 'Globetrotter'
                            WHEN (COUNT(r.review_id) + (COUNT(DISTINCT i.itinerary_id) * 2)) < 20 THEN 'Wanderer'
                            ELSE 'Legend'
                        END
                        FROM users _u
                        LEFT JOIN reviews r ON r.user_id = _u.user_id AND r.status = 'approved'
                        LEFT JOIN itineraries i ON i.user_id = _u.user_id
                        WHERE _u.user_id = u.user_id
                    ) AS traveler_level
             FROM users u
             WHERE u.user_id = :id AND u.is_active = TRUE"
        );
        $stmt->execute([':id' => $userId]);
        return $stmt->fetch() ?: null;
    }

    // ── Update profile ────────────────────────────────────────
    public function updateProfile(int $userId, array $data): bool
    {
        $stmt = $this->db->prepare(
            'UPDATE users
             SET full_name   = :fn,
                 budget_pref = :bp,
                 interests   = :in,
                 updated_at  = NOW()
             WHERE user_id = :id'
        );
        return $stmt->execute([
            ':fn' => sanitize($data['full_name'] ?? ''),
            ':bp' => $data['budget_pref'] ?? 'mid-range',
            ':in' => sanitize($data['interests'] ?? ''),
            ':id' => $userId,
        ]);
    }

    // ── Change password ───────────────────────────────────────
    public function changePassword(int $userId, string $oldPass, string $newPass): array
    {
        $stmt = $this->db->prepare('SELECT password_hash FROM users WHERE user_id = :id');
        $stmt->execute([':id' => $userId]);
        $row = $stmt->fetch();

        if (!$row || !verifyPassword($oldPass, $row['password_hash'])) {
            return ['success' => false, 'error' => 'Current password is incorrect.'];
        }

        $stmt = $this->db->prepare(
            'UPDATE users SET password_hash = :p WHERE user_id = :id'
        );
        $stmt->execute([':p' => hashPassword($newPass), ':id' => $userId]);
        return ['success' => true];
    }

    // ── Get all users (admin) ─────────────────────────────────
    public function getAllUsers(string $roleFilter = ''): array
    {
        // JOIN with subquery for itinerary and review counts
        $sql = "SELECT u.user_id, u.username, u.email, u.full_name, u.role,
                       u.budget_pref, u.is_active,
                       DATE_FORMAT(u.created_at,'%Y-%m-%d') AS joined,
                       COUNT(DISTINCT i.itinerary_id) AS itinerary_count,
                       COUNT(DISTINCT r.review_id)    AS review_count
                FROM users u
                LEFT JOIN itineraries i ON i.user_id = u.user_id
                LEFT JOIN reviews     r ON r.user_id = u.user_id";
        if ($roleFilter) {
            $sql .= " WHERE u.role = :role";
        }
        $sql .= " GROUP BY u.user_id ORDER BY u.created_at DESC";

        $stmt = $this->db->prepare($sql);
        if ($roleFilter) $stmt->bindValue(':role', $roleFilter);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    // ── Toggle user active status (admin) ────────────────────
    public function toggleUserStatus(int $targetId, bool $active): bool
    {
        $stmt = $this->db->prepare(
            'UPDATE users SET is_active = :a WHERE user_id = :id'
        );
        return $stmt->execute([':a' => (int)$active, ':id' => $targetId]);
    }

    // ── Delete user with transaction ──────────────────────────
    public function deleteUser(int $adminId, int $targetId): array
    {
        try {
            $this->db->beginTransaction();

            // Audit before deleting
            $stmt = $this->db->prepare(
                "INSERT INTO audit_log (user_id, action, table_name, record_id, old_value)
                 SELECT :admin, 'DELETE_USER', 'users', user_id, username FROM users WHERE user_id = :tid"
            );
            $stmt->execute([':admin' => $adminId, ':tid' => $targetId]);

            // Delete cascades via FK (itineraries, favorites, reviews)
            $stmt = $this->db->prepare('DELETE FROM users WHERE user_id = :id');
            $stmt->execute([':id' => $targetId]);

            $this->db->commit();
            return ['success' => true];
        } catch (PDOException $e) {
            $this->db->rollBack();
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
}
