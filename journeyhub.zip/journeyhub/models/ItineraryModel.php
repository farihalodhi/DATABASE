<?php
// =============================================================
// models/ItineraryModel.php
// =============================================================
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';

class ItineraryModel
{
    private PDO $db;

    public function __construct()
    {
        $this->db = getDB();
    }

    // ── Create itinerary (uses stored procedure) ──────────────
    public function create(int $userId, array $data): array
    {
        $stmt = $this->db->prepare(
            'CALL sp_create_itinerary(:uid,:did,:title,:sd,:ed,:bud,@iid,@msg)'
        );
        $stmt->execute([
            ':uid'   => $userId,
            ':did'   => !empty($data['destination_id']) ? (int)$data['destination_id'] : null,
            ':title' => sanitize($data['title']),
            ':sd'    => $data['start_date'] ?? null,
            ':ed'    => $data['end_date']   ?? null,
            ':bud'   => !empty($data['total_budget']) ? (float)$data['total_budget'] : null,
        ]);

        $row = $this->db->query('SELECT @iid AS itinerary_id, @msg AS message')->fetch();
        return [
            'success'      => (int)$row['itinerary_id'] > 0,
            'itinerary_id' => (int)$row['itinerary_id'],
            'message'      => $row['message'],
        ];
    }

    // ── Get user's itineraries (uses view) ────────────────────
    public function getUserItineraries(int $userId): array
    {
        $stmt = $this->db->prepare(
            'SELECT * FROM vw_user_itineraries WHERE user_id = :uid ORDER BY created_at DESC'
        );
        $stmt->execute([':uid' => $userId]);
        return $stmt->fetchAll();
    }

    // ── Get single itinerary with all items ───────────────────
    // Uses: multi-table JOIN, DATE_FORMAT, CONCAT, TIMEDIFF
    public function getWithItems(int $itineraryId, int $userId): ?array
    {
        // Header
        $stmt = $this->db->prepare(
            "SELECT i.*, d.city, d.country,
                    DATE_FORMAT(i.start_date,'%d %b %Y') AS formatted_start,
                    DATE_FORMAT(i.end_date,  '%d %b %Y') AS formatted_end,
                    fn_trip_duration(i.start_date, i.end_date) AS trip_days
             FROM itineraries i
             LEFT JOIN destinations d ON d.destination_id = i.destination_id
             WHERE i.itinerary_id = :iid
               AND (i.user_id = :uid OR i.is_public = TRUE)"
        );
        $stmt->execute([':iid' => $itineraryId, ':uid' => $userId]);
        $itinerary = $stmt->fetch();
        if (!$itinerary) return null;

        // Items
        $stmt2 = $this->db->prepare(
            "SELECT ii.item_id, ii.day_number, ii.visit_time, ii.duration_mins,
                    ii.notes, ii.order_in_day,
                    a.name AS attraction_name, a.type AS attraction_type,
                    a.address, a.price_range,
                    fn_price_symbol(a.price_range) AS price_symbol
             FROM itinerary_items ii
             LEFT JOIN attractions a ON a.attraction_id = ii.attraction_id
             WHERE ii.itinerary_id = :iid
             ORDER BY ii.day_number, ii.order_in_day"
        );
        $stmt2->execute([':iid' => $itineraryId]);
        $itinerary['items'] = $stmt2->fetchAll();

        return $itinerary;
    }

    // ── Update itinerary metadata ─────────────────────────────
    public function update(int $itineraryId, int $userId, array $data): array
    {
        try {
            $this->db->beginTransaction();

            $stmt = $this->db->prepare(
                'UPDATE itineraries
                 SET title        = :ti,
                     start_date   = :sd,
                     end_date     = :ed,
                     total_budget = :bud,
                     notes        = :no,
                     is_public    = :ip,
                     updated_at   = NOW()
                 WHERE itinerary_id = :iid AND user_id = :uid'
            );
            $stmt->execute([
                ':ti'  => sanitize($data['title']),
                ':sd'  => $data['start_date']   ?? null,
                ':ed'  => $data['end_date']     ?? null,
                ':bud' => !empty($data['total_budget']) ? (float)$data['total_budget'] : null,
                ':no'  => sanitize($data['notes'] ?? ''),
                ':ip'  => (int)($data['is_public'] ?? 0),
                ':iid' => $itineraryId,
                ':uid' => $userId,
            ]);

            if ($stmt->rowCount() === 0) {
                $this->db->rollBack();
                return ['success' => false, 'error' => 'Itinerary not found or access denied.'];
            }

            $this->db->commit();
            return ['success' => true];
        } catch (PDOException $e) {
            $this->db->rollBack();
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    // ── Add item to itinerary (with transaction + audit) ──────
    public function addItem(int $itineraryId, int $userId, array $item): array
    {
        try {
            $this->db->beginTransaction();

            // Verify ownership
            $own = $this->db->prepare('SELECT user_id FROM itineraries WHERE itinerary_id = :iid');
            $own->execute([':iid' => $itineraryId]);
            $row = $own->fetch();
            if (!$row || (int)$row['user_id'] !== $userId) {
                $this->db->rollBack();
                return ['success' => false, 'error' => 'Itinerary not found or access denied.'];
            }

            $stmt = $this->db->prepare(
                'INSERT INTO itinerary_items
                 (itinerary_id, attraction_id, day_number, visit_time, duration_mins, notes, order_in_day)
                 VALUES (:iid,:aid,:dn,:vt,:dur,:no,:ord)'
            );
            $stmt->execute([
                ':iid'  => $itineraryId,
                ':aid'  => !empty($item['attraction_id']) ? (int)$item['attraction_id'] : null,
                ':dn'   => (int)($item['day_number'] ?? 1),
                ':vt'   => $item['visit_time'] ?? null,
                ':dur'  => !empty($item['duration_mins']) ? (int)$item['duration_mins'] : null,
                ':no'   => sanitize($item['notes'] ?? ''),
                ':ord'  => (int)($item['order_in_day'] ?? 1),
            ]);
            $newItemId = (int)$this->db->lastInsertId();

            // Audit log
            $this->db->prepare(
                "INSERT INTO audit_log (user_id, action, table_name, record_id)
                 VALUES (:uid,'ADD_ITINERARY_ITEM','itinerary_items',:rid)"
            )->execute([':uid' => $userId, ':rid' => $newItemId]);

            $this->db->commit();
            return ['success' => true, 'item_id' => $newItemId];
        } catch (PDOException $e) {
            $this->db->rollBack();
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    // ── Remove item from itinerary ────────────────────────────
    public function removeItem(int $itemId, int $userId): bool
    {
        // JOIN to verify ownership
        $stmt = $this->db->prepare(
            'DELETE ii FROM itinerary_items ii
             JOIN itineraries i ON i.itinerary_id = ii.itinerary_id
             WHERE ii.item_id = :iid AND i.user_id = :uid'
        );
        $stmt->execute([':iid' => $itemId, ':uid' => $userId]);
        return $stmt->rowCount() > 0;
    }

    // ── Delete itinerary ──────────────────────────────────────
    public function delete(int $itineraryId, int $userId): bool
    {
        $stmt = $this->db->prepare(
            'DELETE FROM itineraries WHERE itinerary_id = :iid AND user_id = :uid'
        );
        $stmt->execute([':iid' => $itineraryId, ':uid' => $userId]);
        return $stmt->rowCount() > 0;
    }

    // ── Public itineraries feed ───────────────────────────────
    public function getPublicFeed(int $limit = 20): array
    {
        $stmt = $this->db->prepare(
            'SELECT * FROM vw_user_itineraries
             WHERE is_public = TRUE
             ORDER BY created_at DESC LIMIT :lim'
        );
        $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
