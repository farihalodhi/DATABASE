<?php
// =============================================================
// models/ItineraryModel.php
// =============================================================
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';

class ItineraryModel
{
    private PDO $db;

    public function __construct()
    {
        $this->db = getDB();
    }

    // ── Get list of itineraries for user ──────────────────────
    public function getUserItineraries(int $userId): array
    {
        $stmt = $this->db->prepare(
            'SELECT * FROM vw_user_itineraries WHERE user_id = :uid ORDER BY created_at DESC'
        );
        $stmt->execute([':uid' => $userId]);
        return $stmt->fetchAll();
    }

    // ── Get single itinerary with all items ───────────────────
    public function getWithItems(int $itineraryId, int $userId): ?array
    {
        // Header
        $stmt = $this->db->prepare(
            "SELECT i.*, d.city, d.country,
                    DATE_FORMAT(i.start_date,'%d %b %Y') AS formatted_start,
                    DATE_FORMAT(i.end_date,  '%d %b %Y') AS formatted_end,
                    (DATEDIFF(i.end_date, i.start_date) + 1) AS trip_days
             FROM itineraries i
             LEFT JOIN destinations d ON d.destination_id = i.destination_id
             WHERE i.itinerary_id = :iid
               AND (i.user_id = :uid OR i.is_public = TRUE)"
        );
        $stmt->execute([':iid' => $itineraryId, ':uid' => $userId]);
        $itinerary = $stmt->fetch();
        if (!$itinerary) return null;

        // Items
        $stmt2 = $this->db->prepare(
            "SELECT ii.item_id, ii.day_number, ii.visit_time, ii.duration_mins,
                    ii.notes, ii.order_in_day,
                    a.name AS attraction_name, a.type AS attraction_type,
                    a.address, a.price_range,
                    CASE a.price_range
                        WHEN 'free'      THEN 'Free'
                        WHEN 'budget'    THEN '$'
                        WHEN 'mid-range' THEN '$$'
                        WHEN 'luxury'    THEN '$$$'
                        ELSE '?'
                    END AS price_symbol
             FROM itinerary_items ii
             LEFT JOIN attractions a ON a.attraction_id = ii.attraction_id
             WHERE ii.itinerary_id = :iid
             ORDER BY ii.day_number, ii.order_in_day, ii.visit_time"
        );
        $stmt2->execute([':iid' => $itineraryId]);
        $itinerary['items'] = $stmt2->fetchAll();

        return $itinerary;
    }

    // ── Create new itinerary ──────────────────────────────────
    public function create(int $userId, array $data): array
    {
        $stmt = $this->db->prepare(
            'INSERT INTO itineraries (user_id, destination_id, title, start_date, end_date, total_budget, notes, is_public)
             VALUES (:uid, :did, :title, :start, :end, :budget, :notes, :public)'
        );
        $stmt->execute([
            ':uid'    => $userId,
            ':did'    => (int)$data['destination_id'],
            ':title'  => sanitize($data['title']),
            ':start'  => $data['start_date'] ?? null,
            ':end'    => $data['end_date'] ?? null,
            ':budget' => (float)($data['total_budget'] ?? 0),
            ':notes'  => sanitize($data['notes'] ?? ''),
            ':public' => (int)($data['is_public'] ?? 0),
        ]);

        return [
            'success'      => true,
            'itinerary_id' => (int)$this->db->lastInsertId(),
            'message'      => 'Trip plan created!'
        ];
    }

    // ── Update itinerary ──────────────────────────────────────
    public function update(int $id, int $userId, array $data): array
    {
        $allowedFields = ['title', 'start_date', 'end_date', 'total_budget', 'notes', 'is_public', 'status', 'is_featured'];
        $sets = [];
        $params = [':id' => $id];
        
        $isAdmin = (currentRole() === 'admin');
        if (!$isAdmin) $params[':uid'] = $userId;

        foreach ($allowedFields as $field) {
            if (isset($data[$field])) {
                $val = $data[$field];
                if ($field === 'title' || $field === 'notes') $val = sanitize($val);
                $sets[] = "$field = :$field";
                $params[":$field"] = $val;
            }
        }

        if (empty($sets)) return ['success' => false, 'error' => 'No fields to update.'];

        $sql = "UPDATE itineraries SET " . implode(', ', $sets) . " WHERE itinerary_id = :id";
        if (!$isAdmin) $sql .= " AND user_id = :uid";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);

        return ['success' => true];
    }

    // ── Complete itinerary ─────────────────────────────────────
    public function complete(int $id, int $userId): array
    {
        // Must have at least one item
        $stmtCheck = $this->db->prepare('SELECT COUNT(*) FROM itinerary_items WHERE itinerary_id = :id');
        $stmtCheck->execute([':id' => $id]);
        if ($stmtCheck->fetchColumn() == 0) {
            return ['success' => false, 'error' => 'Add at least one attraction before completing your trip.'];
        }

        $stmt = $this->db->prepare(
            "UPDATE itineraries SET status = 'completed' WHERE itinerary_id = :id AND user_id = :uid"
        );
        $stmt->execute([':id' => $id, ':uid' => $userId]);
        return ['success' => true];
    }

    // ── Delete itinerary with security check ───────────────────
    public function delete(int $id, int $userId): bool
    {
        // Cannot delete completed trips
        $stmt = $this->db->prepare('SELECT status FROM itineraries WHERE itinerary_id = :id AND user_id = :uid');
        $stmt->execute([':id' => $id, ':uid' => $userId]);
        $status = $stmt->fetchColumn();

        if ($status === 'completed') return false;

        $stmt = $this->db->prepare('DELETE FROM itineraries WHERE itinerary_id = :id AND user_id = :uid');
        $stmt->execute([':id' => $id, ':uid' => $userId]);
        return $stmt->rowCount() > 0;
    }

    // ── Add item to itinerary (with transaction + audit) ──────
    public function addItem(int $itineraryId, int $userId, array $item): array
    {
        try {
            $this->db->beginTransaction();

            // Verify ownership
            $own = $this->db->prepare('SELECT user_id FROM itineraries WHERE itinerary_id = :iid');
            $own->execute([':iid' => $itineraryId]);
            $row = $own->fetch();
            if (!$row || (int)$row['user_id'] !== $userId) {
                $this->db->rollBack();
                return ['success' => false, 'error' => 'Itinerary not found or access denied.'];
            }

            $stmt = $this->db->prepare(
                'INSERT INTO itinerary_items
                 (itinerary_id, attraction_id, day_number, visit_time, duration_mins, notes, order_in_day)
                 VALUES (:iid,:aid,:dn,:vt,:dur,:no,:ord)'
            );
            $stmt->execute([
                ':iid' => $itineraryId,
                ':aid' => (int)$item['attraction_id'],
                ':dn'  => (int)($item['day_number'] ?? 1),
                ':vt'  => $item['visit_time'] ?? null,
                ':dur' => (int)($item['duration_mins'] ?? 60),
                ':no'  => sanitize($item['notes'] ?? ''),
                ':ord' => (int)($item['order_in_day'] ?? 0),
            ]);
            $newItemId = (int)$this->db->lastInsertId();

            // Audit
            $this->db->prepare(
                "INSERT INTO audit_log (user_id, action, table_name, record_id)
                 VALUES (:uid, 'ADD_ITINERARY_ITEM', 'itinerary_items', :rid)"
            )->execute([':uid' => $userId, ':rid' => $newItemId]);

            $this->db->commit();
            return ['success' => true, 'item_id' => $newItemId];
        } catch (PDOException $e) {
            $this->db->rollBack();
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    // ── Update item in itinerary ──────────────────────────────
    public function updateItem(int $itemId, int $userId, array $data): bool
    {
        // Verify ownership via itinerary
        $stmt = $this->db->prepare(
            'UPDATE itinerary_items ii
             JOIN itineraries i ON i.itinerary_id = ii.itinerary_id
             SET ii.notes = :notes, ii.visit_time = :vt, ii.duration_mins = :dur, ii.day_number = :dn
             WHERE ii.item_id = :iid AND i.user_id = :uid'
        );
        return $stmt->execute([
            ':notes' => sanitize($data['notes'] ?? ''),
            ':vt'    => $data['visit_time'] ?? null,
            ':dur'   => (int)($data['duration_mins'] ?? 60),
            ':dn'    => (int)($data['day_number'] ?? 1),
            ':iid'   => $itemId,
            ':uid'   => $userId
        ]);
    }

    // ── Remove item ───────────────────────────────────────────
    public function removeItem(int $itemId, int $userId): bool
    {
        $stmt = $this->db->prepare(
            'DELETE ii FROM itinerary_items ii
             JOIN itineraries i ON i.itinerary_id = ii.itinerary_id
             WHERE ii.item_id = :iid AND i.user_id = :uid'
        );
        $stmt->execute([':iid' => $itemId, ':uid' => $userId]);
        return $stmt->rowCount() > 0;
    }

    // ── Public itineraries feed ───────────────────────────────
    public function getPublicFeed(int $limit = 20): array
    {
        $stmt = $this->db->prepare(
            "SELECT * FROM vw_user_itineraries
             WHERE is_public = 1 AND status = 'completed'
             ORDER BY is_featured DESC, created_at DESC LIMIT :lim"
        );
        $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    // ── Admin-created customized trips (Featured) ─────────────
    public function getAdminItineraries(int $limit = 6): array
    {
        $stmt = $this->db->prepare(
            "SELECT v.* FROM vw_user_itineraries v
             JOIN users u ON u.user_id = v.user_id
             WHERE u.role IN ('admin', 'content_manager', 'tourism_official') 
               AND v.is_public = TRUE
             ORDER BY v.is_featured DESC, v.created_at DESC LIMIT :lim"
        );
        $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    // ── Clone itinerary (duplicate header + items) ────────────
    public function clone(int $itineraryId, int $userId): array
    {
        try {
            $this->db->beginTransaction();

            $orig = $this->getWithItems($itineraryId, $userId);
            if (!$orig) {
                $this->db->rollBack();
                return ['success' => false, 'error' => 'Itinerary not found or access denied.'];
            }

            $stmt = $this->db->prepare(
                'INSERT INTO itineraries (user_id, destination_id, title, start_date, end_date, total_budget, notes, is_public)
                 VALUES (:uid, :did, :title, :sd, :ed, :bud, :no, 0)'
            );
            $stmt->execute([
                ':uid'   => $userId,
                ':did'   => $orig['destination_id'],
                ':title' => 'Copy of ' . $orig['title'],
                ':sd'    => $orig['start_date'],
                ':ed'    => $orig['end_date'],
                ':bud'   => $orig['total_budget'],
                ':no'    => $orig['notes'],
            ]);
            $newId = (int)$this->db->lastInsertId();

            if (!empty($orig['items'])) {
                $itemStmt = $this->db->prepare(
                    'INSERT INTO itinerary_items (itinerary_id, attraction_id, day_number, visit_time, duration_mins, notes, order_in_day)
                     SELECT :new_id, attraction_id, day_number, visit_time, duration_mins, notes, order_in_day
                     FROM itinerary_items WHERE itinerary_id = :old_id'
                );
                $itemStmt->execute([':new_id' => $newId, ':old_id' => $itineraryId]);
            }

            $this->db->prepare(
                "INSERT INTO audit_log (user_id, action, table_name, record_id, old_value)
                 VALUES (:uid, 'CLONE_ITINERARY', 'itineraries', :rid, :oid)"
            )->execute([':uid' => $userId, ':rid' => $newId, ':oid' => $itineraryId]);

            $this->db->commit();
            return ['success' => true, 'itinerary_id' => $newId];
        } catch (PDOException $e) {
            $this->db->rollBack();
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
}
