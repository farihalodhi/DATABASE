<?php
// =============================================================
// models/RecommendationModel.php
// Handles sp_get_recommendations stored procedure call
// =============================================================
require_once __DIR__ . '/../config/db.php';

class RecommendationModel
{
    private PDO $db;

    public function __construct()
    {
        $this->db = getDB();
    }

    // ── Get personalised recommendations for a user ───────────
    // Calls: sp_get_recommendations(user_id)
    // Returns attractions filtered by budget_pref + interests,
    // excluding already-favourited items, ordered by rating DESC
    public function getForUser(int $userId): array
    {
        try {
            // Call the stored procedure
            $stmt = $this->db->prepare("CALL sp_get_recommendations(:uid)");
            $stmt->execute([':uid' => $userId]);
            $results = $stmt->fetchAll();

            // Close cursor so subsequent queries work (required after CALL)
            $stmt->closeCursor();

            return $results;
        } catch (PDOException $e) {
            // If stored procedure fails, fall back to top-rated query
            return $this->fallback($userId);
        }
    }

    // ── Fallback: top-rated attractions not yet favourited ────
    // Used if sp_get_recommendations is unavailable
    private function fallback(int $userId): array
    {
        $stmt = $this->db->prepare(
            "SELECT a.attraction_id, a.name, a.type, a.description,
                    a.price_range, a.rating_avg, a.review_count,
                    d.destination_id, d.city, d.country
             FROM attractions a
             JOIN destinations d ON d.destination_id = a.destination_id
             WHERE a.is_active = TRUE
               AND a.attraction_id NOT IN (
                   SELECT attraction_id FROM favorites
                   WHERE user_id = :uid AND attraction_id IS NOT NULL
               )
             ORDER BY a.rating_avg DESC, a.review_count DESC
             LIMIT 20"
        );
        $stmt->execute([':uid' => $userId]);
        return $stmt->fetchAll();
    }
}
