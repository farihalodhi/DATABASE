<?php
// =============================================================
// models/ReviewModel.php
// =============================================================
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';

class ReviewModel
{
    private PDO $db;

    public function __construct()
    {
        $this->db = getDB();
    }

    // ── Post a review (traveler) ──────────────────────────────
    // Trigger trg_after_review_insert fires automatically on approved
    public function post(int $userId, array $data): array
    {
        // Validate: must target exactly one entity
        $hasAttraction  = !empty($data['attraction_id']);
        $hasDestination = !empty($data['destination_id']);
        if ($hasAttraction === $hasDestination) {
            return ['success' => false, 'error' => 'Review must target either an attraction OR a destination, not both.'];
        }

        // One review per user per entity
        if ($hasAttraction) {
            $check = $this->db->prepare(
                'SELECT review_id FROM reviews WHERE user_id = :uid AND attraction_id = :eid'
            );
            $check->execute([':uid' => $userId, ':eid' => (int)$data['attraction_id']]);
        } else {
            $check = $this->db->prepare(
                'SELECT review_id FROM reviews WHERE user_id = :uid AND destination_id = :eid'
            );
            $check->execute([':uid' => $userId, ':eid' => (int)$data['destination_id']]);
        }
        if ($check->fetch()) {
            return ['success' => false, 'error' => 'You have already reviewed this.'];
        }

        $stmt = $this->db->prepare(
            "INSERT INTO reviews (user_id, attraction_id, destination_id, rating, title, content, status)
             VALUES (:uid, :aid, :did, :rat, :tit, :con, 'approved')"
        );
        $stmt->execute([
            ':uid' => $userId,
            ':aid' => $hasAttraction  ? (int)$data['attraction_id']  : null,
            ':did' => $hasDestination ? (int)$data['destination_id'] : null,
            ':rat' => (int)$data['rating'],
            ':tit' => sanitize($data['title'] ?? ''),
            ':con' => sanitize($data['content'] ?? ''),
        ]);

        return ['success' => true, 'review_id' => (int)$this->db->lastInsertId(),
                'message' => 'Review submitted successfully.'];
    }

    // ── Get approved reviews for attraction ───────────────────
    // Uses: INNER JOIN, DATE_FORMAT, AVG (aggregate)
    public function getForAttraction(int $attractionId): array
    {
        $stmt = $this->db->prepare(
            "SELECT r.review_id, r.rating, r.title, r.content,
                    DATE_FORMAT(r.created_at,'%d %b %Y') AS review_date,
                    u.username, u.full_name
             FROM reviews r
             JOIN users u ON u.user_id = r.user_id
             WHERE r.attraction_id = :aid AND r.status = 'approved'
             ORDER BY r.created_at DESC"
        );
        $stmt->execute([':aid' => $attractionId]);
        return $stmt->fetchAll();
    }

    // ── Get approved reviews for destination ─────────────────
    public function getForDestination(int $destId): array
    {
        $stmt = $this->db->prepare(
            "SELECT r.review_id, r.rating, r.title, r.content,
                    DATE_FORMAT(r.created_at,'%d %b %Y') AS review_date,
                    u.username, u.full_name
             FROM reviews r
             JOIN users u ON u.user_id = r.user_id
             WHERE r.destination_id = :did AND r.status = 'approved'
             ORDER BY r.created_at DESC"
        );
        $stmt->execute([':did' => $destId]);
        return $stmt->fetchAll();
    }

    // ── Get user's own reviews ────────────────────────────────
    public function getUserReviews(int $userId): array
    {
        $stmt = $this->db->prepare(
            "SELECT r.review_id, r.rating, r.title, r.content, r.status,
                    DATE_FORMAT(r.created_at,'%d %b %Y') AS review_date,
                    COALESCE(a.name, CONCAT(d.city,', ',d.country)) AS reviewed_entity,
                    CASE WHEN r.attraction_id IS NOT NULL THEN 'attraction' ELSE 'destination' END AS review_type
             FROM reviews r
             LEFT JOIN attractions a  ON a.attraction_id  = r.attraction_id
             LEFT JOIN destinations d ON d.destination_id = r.destination_id
             WHERE r.user_id = :uid
             ORDER BY r.created_at DESC"
        );
        $stmt->execute([':uid' => $userId]);
        return $stmt->fetchAll();
    }

    // ── Delete own review ─────────────────────────────────────
    public function deleteOwn(int $reviewId, int $userId): bool
    {
        $stmt = $this->db->prepare(
            'DELETE FROM reviews WHERE review_id = :rid AND user_id = :uid'
        );
        $stmt->execute([':rid' => $reviewId, ':uid' => $userId]);
        return $stmt->rowCount() > 0;
    }

    // ── Get pending reviews (admin) ───────────────────────────
    public function getPending(): array
    {
        return $this->db->query(
            "SELECT r.review_id, r.rating, r.title, r.content, r.created_at,
                    u.username, u.email,
                    COALESCE(a.name, CONCAT(d.city,', ',d.country)) AS reviewed_entity,
                    CASE WHEN r.attraction_id IS NOT NULL THEN 'attraction' ELSE 'destination' END AS review_type
             FROM reviews r
             JOIN users u ON u.user_id = r.user_id
             LEFT JOIN attractions a  ON a.attraction_id  = r.attraction_id
             LEFT JOIN destinations d ON d.destination_id = r.destination_id
             WHERE r.status = 'pending'
             ORDER BY r.created_at ASC"
        )->fetchAll();
    }

    // ── Moderate (admin) – calls stored procedure ─────────────
    public function moderate(int $adminId, int $reviewId, string $status): array
    {
        if (!in_array($status, ['approved', 'rejected'], true)) {
            return ['success' => false, 'error' => 'Invalid status.'];
        }
        $stmt = $this->db->prepare('CALL sp_moderate_review(:admin,:rev,:st)');
        $stmt->execute([':admin' => $adminId, ':rev' => $reviewId, ':st' => $status]);
        return ['success' => true, 'message' => "Review $status successfully."];
    }

    // ── Rating statistics for attraction (GROUP BY) ───────────
    public function getRatingStats(int $attractionId): array
    {
        $stmt = $this->db->prepare(
            "SELECT rating,
                    COUNT(*)            AS count,
                    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER(), 1) AS percentage
             FROM reviews
             WHERE attraction_id = :aid AND status = 'approved'
             GROUP BY rating
             ORDER BY rating DESC"
        );
        $stmt->execute([':aid' => $attractionId]);
        return $stmt->fetchAll();
    }

    // ── Admin: All reviews with filters ──────────────────────
    public function getAll(string $statusFilter = ''): array
    {
        $sql = "SELECT * FROM vw_approved_reviews";
        if ($statusFilter === 'pending') {
            // Re-query the raw table for pending
            return $this->getPending();
        }
        $stmt = $this->db->query($sql . " ORDER BY created_at DESC");
        return $stmt->fetchAll();
    }
}
