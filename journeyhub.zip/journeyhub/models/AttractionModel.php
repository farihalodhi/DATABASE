<?php
// =============================================================
// models/AttractionModel.php
// =============================================================
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';

class AttractionModel
{
    private PDO $db;

    public function __construct()
    {
        $this->db = getDB();
    }

    // ── Search attractions (uses view + dynamic filters) ──────
    public function search(array $filters): array
    {
        $sql = "SELECT * FROM vw_attraction_details WHERE 1=1";
        $params = [];

        if (!empty($filters['type'])) {
            $sql .= " AND type = :type";
            $params[':type'] = $filters['type'];
        }
        if (!empty($filters['price_range'])) {
            $sql .= " AND price_range = :pr";
            $params[':pr'] = $filters['price_range'];
        }
        if (!empty($filters['city'])) {
            $sql .= " AND city = :city";
            $params[':city'] = $filters['city'];
        }
        if (!empty($filters['keyword'])) {
            $sql .= " AND (attraction_name LIKE :kw OR description LIKE :kw)";
            $params[':kw'] = '%' . $filters['keyword'] . '%';
        }
        if (!empty($filters['min_rating'])) {
            $sql .= " AND rating_avg >= :mr";
            $params[':mr'] = (float)$filters['min_rating'];
        }

        $sql .= " ORDER BY rating_avg DESC, review_count DESC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    // ── Get single attraction ──────────────────────────────────
    public function getById(int $id): ?array
    {
        $stmt = $this->db->prepare(
            'SELECT * FROM vw_attraction_details WHERE attraction_id = :id'
        );
        $stmt->execute([':id' => $id]);
        return $stmt->fetch() ?: null;
    }

    // ── Get top-rated in a destination (uses window view) ─────
    public function getTopRated(int $destId, int $topN = 5): array
    {
        $stmt = $this->db->prepare(
            'SELECT * FROM vw_top_attractions
             WHERE city = (SELECT city FROM destinations WHERE destination_id = :did)
               AND rank_in_destination <= :n
             ORDER BY rank_in_destination'
        );
        $stmt->execute([':did' => $destId, ':n' => $topN]);
        return $stmt->fetchAll();
    }

    // ── Add attraction (content_manager / admin) ──────────────
    public function create(array $data): array
    {
        try {
            $this->db->beginTransaction();

            $stmt = $this->db->prepare(
                'INSERT INTO attractions
                 (destination_id, category_id, name, type, description, address, price_range, opening_hours)
                 VALUES (:did,:cid,:na,:ty,:de,:ad,:pr,:oh)'
            );
            $stmt->execute([
                ':did' => (int)$data['destination_id'],
                ':cid' => !empty($data['category_id']) ? (int)$data['category_id'] : null,
                ':na'  => sanitize($data['name']),
                ':ty'  => $data['type'],
                ':de'  => sanitize($data['description'] ?? ''),
                ':ad'  => sanitize($data['address'] ?? ''),
                ':pr'  => $data['price_range'] ?? 'mid-range',
                ':oh'  => sanitize($data['opening_hours'] ?? ''),
            ]);
            $newId = (int)$this->db->lastInsertId();
            $this->db->commit();
            return ['success' => true, 'attraction_id' => $newId];
        } catch (PDOException $e) {
            $this->db->rollBack();
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    // ── Update attraction ─────────────────────────────────────
    public function update(int $id, array $data): bool
    {
        $stmt = $this->db->prepare(
            'UPDATE attractions
             SET name          = :na,
                 description   = :de,
                 address       = :ad,
                 price_range   = :pr,
                 opening_hours = :oh,
                 category_id   = :cid
             WHERE attraction_id = :id'
        );
        return $stmt->execute([
            ':na'  => sanitize($data['name']),
            ':de'  => sanitize($data['description'] ?? ''),
            ':ad'  => sanitize($data['address'] ?? ''),
            ':pr'  => $data['price_range'] ?? 'mid-range',
            ':oh'  => sanitize($data['opening_hours'] ?? ''),
            ':cid' => !empty($data['category_id']) ? (int)$data['category_id'] : null,
            ':id'  => $id,
        ]);
    }

    // ── Deactivate attraction ─────────────────────────────────
    public function deactivate(int $id): bool
    {
        $stmt = $this->db->prepare(
            'UPDATE attractions SET is_active = FALSE WHERE attraction_id = :id'
        );
        return $stmt->execute([':id' => $id]);
    }

    // ── Attractions with above-average rating (subquery) ─────
    public function getAboveAverage(): array
    {
        return $this->db->query(
            "SELECT a.attraction_id, a.name, a.type, a.rating_avg, a.review_count,
                    d.city, d.country
             FROM attractions a
             JOIN destinations d ON d.destination_id = a.destination_id
             WHERE a.is_active = TRUE
               AND a.rating_avg > (
                   SELECT AVG(rating_avg) FROM attractions WHERE rating_avg > 0 AND is_active = TRUE
               )
             ORDER BY a.rating_avg DESC"
        )->fetchAll();
    }

    // ── Budget-friendly list (for traveler) ───────────────────
    // Uses: HAVING, GROUP BY, CONCAT, UPPER
    public function getBudgetFriendly(string $city = ''): array
    {
        $sql = "SELECT a.attraction_id, a.name, a.type,
                       UPPER(a.price_range) AS price_label,
                       a.rating_avg,
                       CONCAT(d.city, ', ', d.country) AS location
                FROM attractions a
                JOIN destinations d ON d.destination_id = a.destination_id
                WHERE a.is_active = TRUE
                  AND a.price_range IN ('free','budget')";
        $params = [];
        if ($city) {
            $sql .= " AND d.city = :city";
            $params[':city'] = $city;
        }
        $sql .= " ORDER BY a.rating_avg DESC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    // ── Destination stats (GROUP BY + HAVING) ─────────────────
    public function getDestinationStats(): array
    {
        return $this->db->query(
            "SELECT d.city, d.country,
                    COUNT(a.attraction_id)              AS total_attractions,
                    ROUND(AVG(a.rating_avg),2)          AS avg_attraction_rating,
                    SUM(CASE WHEN a.type='hotel'       THEN 1 ELSE 0 END) AS hotels,
                    SUM(CASE WHEN a.type='restaurant'  THEN 1 ELSE 0 END) AS restaurants,
                    SUM(CASE WHEN a.type='attraction'  THEN 1 ELSE 0 END) AS sights
             FROM destinations d
             JOIN attractions a ON a.destination_id = d.destination_id AND a.is_active = TRUE
             GROUP BY d.destination_id
             HAVING total_attractions > 1
             ORDER BY total_attractions DESC"
        )->fetchAll();
    }
}
