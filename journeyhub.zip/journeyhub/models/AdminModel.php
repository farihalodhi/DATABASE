<?php
// =============================================================
// models/AdminModel.php
// =============================================================
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';

class AdminModel
{
    private PDO $db;

    public function __construct()
    {
        $this->db = getDB();
    }

    // ── Dashboard statistics ──────────────────────────────────
    // Uses: multiple COUNT, SUM, AVG, subqueries
    public function getDashboardStats(): array
    {
        $stats = [];

        // Counts from each major table
        $rows = $this->db->query(
            "SELECT
                (SELECT COUNT(*) FROM users       WHERE is_active = TRUE) AS total_users,
                (SELECT COUNT(*) FROM destinations WHERE is_active = TRUE) AS total_destinations,
                (SELECT COUNT(*) FROM attractions  WHERE is_active = TRUE) AS total_attractions,
                (SELECT COUNT(*) FROM itineraries)                          AS total_itineraries,
                (SELECT COUNT(*) FROM reviews WHERE status = 'pending')    AS pending_reviews,
                (SELECT COUNT(*) FROM reviews WHERE status = 'approved')   AS approved_reviews,
                (SELECT ROUND(AVG(rating),2) FROM reviews WHERE status='approved') AS overall_avg_rating,
                (SELECT COUNT(*) FROM favorites)                            AS total_favorites"
        )->fetch();

        $stats['counts'] = $rows;

        // New users by month (last 6 months) – GROUP BY + DATE functions
        $stats['new_users_monthly'] = $this->db->query(
            "SELECT DATE_FORMAT(created_at,'%Y-%m') AS month,
                    COUNT(*) AS new_users
             FROM users
             WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
             GROUP BY DATE_FORMAT(created_at,'%Y-%m')
             ORDER BY month DESC"
        )->fetchAll();

        // Most reviewed attractions
        $stats['most_reviewed'] = $this->db->query(
            "SELECT a.name, a.type, a.rating_avg, a.review_count, d.city
             FROM attractions a
             JOIN destinations d ON d.destination_id = a.destination_id
             ORDER BY a.review_count DESC LIMIT 5"
        )->fetchAll();

        return $stats;
    }

    // ── Audit log (admin only) ────────────────────────────────
    // Uses: JOIN, DATE_FORMAT, LIKE (dynamic), LIMIT
    public function getAuditLog(array $filters = []): array
    {
        $sql = "SELECT al.log_id, al.action, al.table_name, al.record_id,
                       al.old_value, al.new_value,
                       DATE_FORMAT(al.logged_at,'%d %b %Y %H:%i') AS logged_at,
                       COALESCE(u.username,'system') AS performed_by
                FROM audit_log al
                LEFT JOIN users u ON u.user_id = al.user_id
                WHERE 1=1";
        $params = [];

        if (!empty($filters['action'])) {
            $sql .= " AND al.action LIKE :action";
            $params[':action'] = '%' . $filters['action'] . '%';
        }
        if (!empty($filters['table_name'])) {
            $sql .= " AND al.table_name = :tbl";
            $params[':tbl'] = $filters['table_name'];
        }

        $sql .= " ORDER BY al.logged_at DESC LIMIT 100";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    // ── User report with review & itinerary counts ────────────
    // Uses: LEFT JOIN, GROUP BY, HAVING (users with > 0 itineraries)
    public function getActiveUsersReport(): array
    {
        return $this->db->query(
            "SELECT u.user_id, u.username, u.email, u.role, u.budget_pref,
                    DATE_FORMAT(u.created_at,'%Y-%m-%d') AS joined,
                    COUNT(DISTINCT i.itinerary_id) AS itineraries,
                    COUNT(DISTINCT r.review_id)    AS reviews,
                    COUNT(DISTINCT f.favorite_id)  AS favorites
             FROM users u
             LEFT JOIN itineraries i ON i.user_id = u.user_id
             LEFT JOIN reviews     r ON r.user_id = u.user_id
             LEFT JOIN favorites   f ON f.user_id = u.user_id
             WHERE u.is_active = TRUE AND u.role = 'traveler'
             GROUP BY u.user_id
             HAVING (itineraries + reviews) > 0
             ORDER BY itineraries DESC, reviews DESC"
        )->fetchAll();
    }

    // ── Content report: destinations missing emergency contact ─
    // Uses: IS NULL, LEFT JOIN, WHERE condition
    public function getIncompleteDestinations(): array
    {
        return $this->db->query(
            "SELECT d.destination_id, d.city, d.country,
                    CASE WHEN d.emergency_contact IS NULL THEN 'Missing emergency contact' ELSE '' END AS issue,
                    COUNT(a.attraction_id) AS attraction_count
             FROM destinations d
             LEFT JOIN attractions a ON a.destination_id = d.destination_id
             WHERE d.is_active = TRUE
               AND (d.emergency_contact IS NULL OR d.description IS NULL OR d.description = '')
             GROUP BY d.destination_id"
        )->fetchAll();
    }

    // ── Tourism official: Safety info update ─────────────────
    public function updateEmergencyContact(int $destId, string $contact, int $officialId): array
    {
        try {
            $this->db->beginTransaction();

            $stmt = $this->db->prepare(
                "SELECT emergency_contact FROM destinations WHERE destination_id = :id"
            );
            $stmt->execute([':id' => $destId]);
            $old = $stmt->fetchColumn();

            $this->db->prepare(
                "UPDATE destinations SET emergency_contact = :ec WHERE destination_id = :id"
            )->execute([':ec' => sanitize($contact), ':id' => $destId]);

            // Audit trail
            $this->db->prepare(
                "INSERT INTO audit_log (user_id, action, table_name, record_id, old_value, new_value)
                 VALUES (:uid,'UPDATE_EMERGENCY','destinations',:rid,:old,:new)"
            )->execute([':uid' => $officialId, ':rid' => $destId, ':old' => $old, ':new' => $contact]);

            $this->db->commit();
            return ['success' => true];
        } catch (PDOException $e) {
            $this->db->rollBack();
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    // ── Change user role (admin only) ─────────────────────────
    public function changeUserRole(int $adminId, int $targetId, string $newRole): array
    {
        $allowed = ['traveler', 'admin', 'content_manager', 'tourism_official'];
        if (!in_array($newRole, $allowed, true)) {
            return ['success' => false, 'error' => 'Invalid role.'];
        }

        try {
            $this->db->beginTransaction();

            $old = $this->db->prepare('SELECT role FROM users WHERE user_id = :id');
            $old->execute([':id' => $targetId]);
            $oldRole = $old->fetchColumn();

            $this->db->prepare('UPDATE users SET role = :r WHERE user_id = :id')
                     ->execute([':r' => $newRole, ':id' => $targetId]);

            $this->db->prepare(
                "INSERT INTO audit_log (user_id, action, table_name, record_id, old_value, new_value)
                 VALUES (:aid,'CHANGE_ROLE','users',:tid,:old,:new)"
            )->execute([':aid' => $adminId, ':tid' => $targetId, ':old' => $oldRole, ':new' => $newRole]);

            $this->db->commit();
            return ['success' => true];
        } catch (PDOException $e) {
            $this->db->rollBack();
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }
}
